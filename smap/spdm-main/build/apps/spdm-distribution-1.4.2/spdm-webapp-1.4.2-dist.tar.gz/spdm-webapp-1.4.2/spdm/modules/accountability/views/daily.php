<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>

<h3>Product Accountability</h3>
<p class="generated-timestamp">Information generated as of: <span id="current-date"></span></p>
<div id="tabs">
   <ul>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbitSummary/index.php">Half-Orbit Products</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbit/index.php">Half-Orbit Info</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/dailySummary/index.php">Daily L3 Products</a></li>
      <li><a href="#daily">Daily L3 Info</a></li>
   </ul>
   <div id="daily">
<?php 
$temporalFilterWidget = new TemporalFilterWidget(array('temporalLabel' => "Granule Date"));
$temporalFilterWidget->render();
?>
<br/>
<table id="daily-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Start Orbit</th>
         <th>Stop Orbit</th>
         <th>Granule Date</th>
         <th>Products</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
</div>
</div>
