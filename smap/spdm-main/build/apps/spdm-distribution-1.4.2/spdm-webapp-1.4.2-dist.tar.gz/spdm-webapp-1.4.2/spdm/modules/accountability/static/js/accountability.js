/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

$(document).ready(function() {
  $("#current-date").text((new Date()).toUTCString());

  var tabIndex = 0;
  if ($("#half-orbit-table").length) {
    tabIndex = 2;
    addRefreshListener($("#half-orbit-table"));
  } else if ($("#daily-summary-table").length) {
    tabIndex = 1;
    addRefreshListener($("#daily-summary-table"));
  } else if ($("#daily-table").length) {
    tabIndex = 3;
  } else {
    addRefreshListener($("#half-orbit-summary-table"));
  }
  createTabs(tabIndex);

  //Parse query parameters
  var queryParameters = getQueryParameters();
  var range = queryParameters["range"];
  var start = queryParameters["start"];
  var end = queryParameters["end"];
  var startOrbitNumber = queryParameters["startOrbitNumber"];
  var stopOrbitNumber = queryParameters["stopOrbitNumber"];
  var startGranuleDate = queryParameters["startGranuleDate"];
  var stopGranuleDate = queryParameters["stopGranuleDate"];

  if (tabIndex === 3) { //If only date is required, then ignore time
    if (start && start.match(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)) {
      start = start.substring(0, 10);
    }
    if (end && end.match(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)) {
      end = end.substring(0, 10);
    }
  } else { //Else if date and time is required, then append T00:00:00 to start and T23:59:59 to end
    if (start && start.match(/^\d{4}-\d{2}-\d{2}$/)) {
      start = start + "T00:00:00";
    }
    if (end && end.match(/^\d{4}-\d{2}-\d{2}$/)) {
      end = end + "T23:59:59";
    }
  }

  instantiateTemporalFilterWidget(range, start, end, tabIndex === 3);

  if ($("#half-orbit-table").length) {
    $("input[name=startOrbitNumber]").val(startOrbitNumber);
    $("input[name=stopOrbitNumber]").val(stopOrbitNumber);
    getHalfOrbit(range, start, end, startOrbitNumber, stopOrbitNumber);
  }
  else if ($("#half-orbit-summary-table").length) {
    $("input[name=startOrbitNumber]").val(startOrbitNumber);
    $("input[name=stopOrbitNumber]").val(stopOrbitNumber);
    getHalfOrbitSummary(range, start, end, startOrbitNumber, stopOrbitNumber);
  }
  else if ($("#daily-table").length) {
    getDaily(range, start, end);
  }
  else if ($("#daily-summary-table").length) {
    createDatePicker($('.granule-date-temporal-start'), startGranuleDate);
    createDatePicker($('.granule-date-temporal-stop'), stopGranuleDate);
    getDailySummary(range, start, end, startGranuleDate, stopGranuleDate);
  }
});

function getHalfOrbit(range, start, end, startOrbitNumber, stopOrbitNumber) {
  var summaryUrl = getHalfOrbitUrl(spdmWsUrl + "/orbitsummary/q?", range, start, end, startOrbitNumber, stopOrbitNumber);

  createDataTable("#half-orbit-table",
    [[ 4, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     {
      "mData": 1,
      "aTargets": [ 1 ],
      "mRender": function ( data, type, full ) {
        if ( type === 'display' ) {
          return '<a href="javaScript:void(0);" onclick="displayHalfOrbit('+full.OrbitId+',\'' + full.RadarDataStatus + '\',\'' + full.RadiometerDataStatus + '\');">'+data+'</a>';
        } else {
          return data;
        }
      }
     }
     ],
    summaryUrl,
    [ 
      { "mData": null },
      { "mData": "OrbitKey", "sType": "orbit" },
      { "mData": "RadarDataStatus" },
      { "mData": "RadiometerDataStatus" },
      { "mData": "HalfOrbitStartDateTime" },
      { "mData": "HalfOrbitStopDateTime" },
      { "mData": "RadarBeginningDateTime" },
      { "mData": "RadarEndingDateTime" },
      { "mData": "RadiometerBeginningDateTime" },
      { "mData": "RadiometerEndingDateTime" },
      { "mData": "OrbitPath" },
      { "mData": "BeginEclipseDateTime", "sType": "string_ignore_empty", "sDefaultContent" : "" },
      { "mData": "EndEclipseDateTime", "sType": "string_ignore_empty", "sDefaultContent" : "" },
      { "mData": "Modified" }
    ],
    "products",
    true
  );
}

/**
 * Load Half-Orbit Summary table with data from web service.
 *
 * @param range
 *          today, yesterday, thisMonth, or lastMonth
 * @param start
 *          start date time
 * @param end
 *          end date time
 */
function getHalfOrbitSummary(range, start, end, startOrbitNumber, stopOrbitNumber) {
  var summaryUrl = getHalfOrbitUrl(spdmWsUrl + "/orbitstatus/q?", range, start, end, startOrbitNumber, stopOrbitNumber);

  createDataTable("#half-orbit-summary-table",
    [[ 5, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     { "aTargets": [ "_all" ], 
       "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
         formatSummaryCellStyle(nTd, sData, iCol, true);
       }
     },
     {
       "mData": 1,
       "aTargets": [ 1 ],
       "mRender": function ( data, type, full ) {
         if ( type === 'display' ) {
           return '<a href="javaScript:void(0);" onclick="displayHalfOrbit('+full.OrbitId+',\'' + full.RadarDataStatus + '\',\'' + full.RadiometerDataStatus + '\');">'+data+'</a>';
         } else {
           return data;
         }
       }
      }
    ],
    summaryUrl,
    [
      { "mData": null },
      { "mData": "OrbitKey", "sType": "orbit" },
      { "mData": "RadarDataStatus" },
      { "mData": "RadiometerDataStatus" },
      { "mData": "HalfOrbitStartDateTime" },
      { "mData": "Modified" },
      { "mData": "L0BRadarStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L0BRadar");
        }
      },
      { "mData": "L1ARadarStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1ARadar");
        }
      },
      { "mData": "RadarCalStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "RadarCal");
        }
      },
      { "mData": "L1BS0LoResStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1BS0LoRes");
        }
      },
      { "mData": "L1CS0HiResStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1CS0HiRes");
        }
      },
      { "mData": "L0BRadiometerStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L0BRadiometer");
        }
      },
      { "mData": "L1ARadiometerStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1ARadiometer");
        }
      },
      { "mData": "L1BTBStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1BTB");
        }
      },
      { "mData": "L1BTBEStatus",
          "mRender": function ( data, type, full ) {
            return renderHalfOrbitCell(data, type, full, "L1BTBE");
        }
      },
      { "mData": "L1CTBStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1CTB");
        }
      },
      { "mData": "L1CTBEStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L1CTBE");
        }
      },
      { "mData": "L2SMAStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L2SMA");
        }
      },
      { "mData": "L2SMPStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L2SMP");
        }
      },
      { "mData": "L2SMPEStatus",
          "mRender": function ( data, type, full ) {
           return renderHalfOrbitCell(data, type, full, "L2SMPE");
        }
      },
      { "mData": "L2SMAPStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L2SMAP");
        }
      },
      { "mData": "L2FTAStatus",
        "mRender": function ( data, type, full ) {
          return renderHalfOrbitCell(data, type, full, "L2FTA");
        }
      }
    ],
    "products",
    true
  );
}

function getDaily(range, start, end) {
  var summaryUrl = getSummaryUrl(spdmWsUrl + "/dailysummary/q?", range, start, end, "startDate", "stopDate", true);

  createDataTable("#daily-table",
    [[ 3, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     { 
      "mData": 4,
      "aTargets": [ 4 ],
      "mRender": function ( data, type, full ) {
        if ( type === 'display') {
          var keys = Object.keys(data).sort();
          var list = $("<ul>");
          $.each(keys, function( i, key ) {
            list.append($("<li>").append($("<a>")
                .text(key)
                .attr("href", "javaScript:void(0);")
                .attr("onclick", "displayMetadata('" + key + "');")).append($("<p>").text(data[key])));
          });
          return $("<div />").append(list).html();
        } else {
          return data;
        }
      }}
     ],
    summaryUrl,
    [ 
      { "mData": null },
      { "mData": "StartOrbit" },
      { "mData": "StopOrbit" },
      { "mData": "GranuleDate" },
      { "mData": "pidlist" }
    ],
    "products",
    true
  );
}

/**
 * Load Daily Summary table with data from web service.
 *
 * @param range
 *          today, yesterday, thisMonth, or lastMonth
 * @param start
 *          start date time
 * @param end
 *          end date time
 */
function getDailySummary(range, start, end, startGranuleDate, stopGranuleDate) {
  var summaryUrl = spdmWsUrl + "/dailystatus/q?";
  var params = getProductReceivedTimeRange(range, start, end, "startTime", "stopTime");
  if (startGranuleDate) {
    params["startGranuleDate"] = startGranuleDate;
  }
  if (stopGranuleDate) {
    params["stopGranuleDate"] = stopGranuleDate;
  }
  summaryUrl += jQuery.param( params );

  createDataTable("#daily-summary-table",
    [[ 4, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     { "aTargets": [ "_all" ], 
       "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
         formatSummaryCellStyle(nTd, sData, iCol);
       }
     }
    ],
    summaryUrl,
    [
      { "mData": null },
      { "mData": "StartOrbit", "sType": "orbit" },
      { "mData": "StopOrbit", "sType": "orbit" },
      { "mData": "GranuleDate" },
      { "mData": "Modified" },
      { "mData": "L3SMAStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3SMA");
        }
      },
      { "mData": "L3SMPStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3SMP");
        }
      },
      { "mData": "L3SMPEStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3SMPE");
        }
      },
      { "mData": "L3SMAPStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3SMAP");
        }
      },
      { "mData": "L3FTAStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3FTA");
        }
      },
      { "mData": "L3FTPStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3FTP");
        }
      },
      { "mData": "L3FTPEStatus",
        "mRender": function ( data, type, full ) {
          return renderDailyCell(data, type, full, "L3FTPE");
        }
      }
    ],
    "products",
    true
  );
}

function formatSummaryCellStyle(nTd, sData, iCol, displayId) {
  if (sData.match(/F<\/a>$/)) {
    $(nTd).addClass('failed');
  } else if (sData == 'R') {
    $(nTd).addClass('running');
  } else if (sData.match(/^<a/) && sData.indexOf("displayMetadata") != -1) {
    if (displayId) {
      $(nTd).addClass('processed_id');
    } else {
      $(nTd).addClass('processed');
    }
  } else if (sData == '' && iCol != 0) {
    $(nTd).addClass('blank');
  }
}

function getHalfOrbitUrl(baseUrl, range, start, end, startOrbitNumber, stopOrbitNumber) {
  var summaryUrl = baseUrl;
  var params = getProductReceivedTimeRange(range, start, end, "startTime", "stopTime");
  if (startOrbitNumber) {
    params["startOrbitNumber"] = startOrbitNumber;
  }
  if (stopOrbitNumber) {
    params["stopOrbitNumber"] = stopOrbitNumber;
  }
  summaryUrl += jQuery.param( params );
  return summaryUrl;
}

function displayHalfOrbit(orbitId, radarDataStatus, radiometerDataStatus) {
  $.getJSON( spdmWsUrl + "/orbit/" + orbitId, function( data ) {
    data.orbit["RadarDataStatus"] = radarDataStatus;
    data.orbit["RadiometerDataStatus"] = radiometerDataStatus;
    
    data.orbit["HalfOrbit"] = data.orbit["OrbitKey"];
    data.orbit["LastModified"] = data.orbit["Modified"];
    delete data.orbit["OrbitKey"];
    delete data.orbit["Modified"];
    
    var table = $("<table>");
    table.attr("class", "common");
    
    var keys = Object.keys(data.orbit).sort();
    $.each(keys, function( index, key ) {
      var row = $("<tr>");
      row.append($("<td>").text(key.replace(/([a-z])([A-Z])/g, "$1 $2")));
      row.append($("<td>").text(data.orbit[key]));
      table.append(row);
    });
    var div = $("<div>");
    div.attr("title", "Half Orbit " + data.orbit.HalfOrbit);
    div.append(table);
    div.dialog({
      width: 600,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

function renderHalfOrbitCell(data, type, full, productType) {
  if (data && typeof data === 'object') {
    if (data.Id == -1) {
      if ( type === 'display') {
        return '<a href="javaScript:void(0);" onclick="displayHalfOrbitError('+full.OrbitId+',\''+productType+'\');">F</a>';
      } else {
        return 'F';
      }
    } else if (data.Id == -2) {
      return 'R';
    } else if (data.Id == 0) {
      return '';
    } else if (data.Id > 0) {
      if ( type === 'display') {
        return '<a href="javaScript:void(0);" onclick="displayMetadata(\''+data.ProductName+'\');">'+data.Id+'</a>';
      } else {
        return data.Id
      }
    } else {
      return data;
    }
  } else {
    return data;
  }
}

function renderDailyCell(data, type, full, productType) {
  if (data && data.Status == -1) {
    if ( type === 'display') {
      return '<a href="javaScript:void(0);" onclick="displayDailyError(\''+full.GranuleDate+'\',\''+productType+'\');">F</a>';
    } else {
      return 'F';
    }
  } else if (data && data.Status == -2) {
    return 'R';
  } else if (data && data.Status == 0) {
    return '';
  } else if (data && data.Status > 0) {
    if ( type === 'display') {
      return '<a href="javaScript:void(0);" onclick="displayMetadata(\''+data.FileName+'\');">P</a>&nbsp;' + data.Input;
    } else {
      return 'P ' + data.Input;
    }
  } else {
    return data;
  }
}

function displayHalfOrbitError(orbitId, productType) {
  var queryParams = {
    orbitId : orbitId,
    productType : productType
  };
  $.getJSON( spdmWsUrl + "/orbitstatus/error/q?" + jQuery.param( queryParams ), function( data ) {
    displayErrorDialog(data);
  });
}

function displayDailyError(granuleDate, productType) {
  var queryParams = {
      granuleDate : granuleDate,
      productType : productType
    };
    $.getJSON( spdmWsUrl + "/dailystatus/error/q?" + jQuery.param( queryParams ), function( data ) {
      displayErrorDialog(data);
    });
}
