<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
*/
class TemporalFilterWidget implements Org_Apache_Oodt_Balance_Interfaces_IApplicationWidget {
   public $temporalLabel;
   public $showGdsCheckbox;

   public function __construct($options = array()) {
      if(isset($options['temporalLabel'])){
         $this->temporalLabel = $options['temporalLabel'];
      }
      if(isset($options['showGdsCheckbox'])){
         $this->showGdsCheckbox = $options['showGdsCheckbox'];
      }
   }

   public function render($bEcho = true) {
      $module = App::Get ()->loadModule ();
      
      $str = '';
      $str .= '<form id="temporal-form" action="" method="get">';
      $str .= "<table>";
      $str .= "<tr><td>";
      $str .= $this->temporalLabel;
      $str .= "&nbsp;</td><td>";
      $str .= '<div id="temporal-range">';
      $str .= '<input onchange="this.form.submit();" type="radio" id="temporal-1" name="range" value="today"><label for="temporal-1">Today</label>';
      $str .= '<input onchange="this.form.submit();" type="radio" id="temporal-2" name="range" value="yesterday"><label for="temporal-2">Yesterday</label>';
      $str .= '<input onchange="this.form.submit();" type="radio" id="temporal-3" name="range" value="thisMonth"><label for="temporal-3">This Month</label>';
      $str .= '<input onchange="this.form.submit();" type="radio" id="temporal-4" name="range" value="lastMonth"><label for="temporal-4">Last Month</label>';
      $str .= '</div>';
      $str .= "</td><td>";
      $str .= '<span>&nbsp;or between&nbsp;</span>';
      $str .= '<input type="text" class="temporal-start" />';
      $str .= '<input type="hidden" class="hidden-temporal-start" name="start" />';
      $str .= '<span>&nbsp;and&nbsp;</span>';
      $str .= '<input type="text" class="temporal-end" />';
      $str .= '<input type="hidden" class="hidden-temporal-end" name="end" />';
      if ($this->showGdsCheckbox) {
         $str .= "</td></tr>";
         $str .= "<tr><td></td><td class=\"gds\"><input type=\"checkbox\" name=\"gds\" value=\"true\" />Show GDS Only</td><td></td></tr>";
         $str .= "<tr><td></td><td>";
      }
      $str .= '<button class="temporal-search-button" type="submit">Apply</button>';
      $str .= '<button onclick="window.location=window.location.pathname; return false;">Reset</button>';
      $str .= "</td></tr>";
      $str .= "</table>";
      $str .= '</form>';
      
      if ($bEcho) {
         echo $str;
      } else {
         return $str;
      }
   }
}
?>
