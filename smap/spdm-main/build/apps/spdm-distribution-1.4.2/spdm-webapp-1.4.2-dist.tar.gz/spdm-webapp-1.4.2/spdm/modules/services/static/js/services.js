/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

var intervalId;
$(document).ready(function() {
  $(".status").hide();
  getStatus();
  $('#auto-refresh').click(function() {
    if($(this).val() == "Enable Auto Refresh") {
      $(this).val("Disable Auto Refresh");
      intervalId = setInterval(getStatus, refreshRate);
    } else {
      $(this).val("Enable Auto Refresh");
      clearInterval(intervalId);
    }
  });
});

function getStatus() {
  $.ajax({
    type: "GET",
    url: SERVICE_STATUS_URL,
    dataType: "json",
    cache: false,
    success: function(data) {
      $(".status").show();

      $("#current-date").text((new Date()).toUTCString());
      $("#server").find("tr:gt(0)").remove();
      $("#server").append(createStatusRow(data.status.fm));
      $("#server").append(createStatusRow(data.status.wm));
      $("#server").append(createStatusRow(data.status.rm));

      $("#crawler").find("tr:gt(0)").remove();
      $.each(data.status.crawlers, function() {
        $("#crawler").append(createStatusRow(this));
      });

      $("#batch-stub").find("tr:gt(0)").remove();
      data.status.stubs.sort(function(a, b){
        return a.URL.localeCompare(b.URL);
      });
      $.each(data.status.stubs, function() {
        $("#batch-stub").append(createStatusRowHideName(this));
      });

      $("#timer").find("tr:gt(0)").remove();
      $("#timer").append(createStatusRowHideUrl(data.status.timer));
    },
    error: function(xhr, status, error) {
      $(".status").hide();
      //Clear interval. Otherwise, it will keep pinging server.
      clearInterval(intervalId);
    }
  });
}

function createStatusRow(statusObj) {
  var row = $("<tr>");
  row.append($("<td>").text(statusObj.Name).attr("class", "first-col"));
  row.append($("<td>").text(statusObj.URL).attr("class", "second-col"));
  row.append($("<td>").text(statusObj.ProcessID).attr("class", "third-col"));
  appendStatusColumn(statusObj, row);
  return row;
}

function appendStatusColumn(statusObj, row) {
  var upImg = $("<img>");
  upImg.attr("src", staticUrl + "/img/icon_arrow_up.gif");
  var downImg = $("<img>");
  downImg.attr("src", staticUrl + "/img/icon_arrow_down.gif");

  var iconCell = $("<td>").attr("class", "status-icon");
  if (statusObj.Status == "UP") {
    row.append(iconCell.append(upImg));
  } else {
    row.append(iconCell.append(downImg));
  }
}

function createStatusRowHideName(statusObj) {
  var row = $("<tr>");
  row.append($("<td>").text(statusObj.URL).attr("class", "first-col"));
  row.append($("<td>").text(statusObj.ProcessID).attr("class", "second-col"));
  appendStatusColumn(statusObj, row);
  return row;
}

function createStatusRowHideUrl(statusObj) {
  var row = $("<tr>");
  row.append($("<td>").text(statusObj.Name).attr("class", "first-col"));
  row.append($("<td>").text(statusObj.ProcessID).attr("class", "second-col"));
  appendStatusColumn(statusObj, row);
  return row;
}
