<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
*/
class DataBrowseHeaderWidget implements Org_Apache_Oodt_Balance_Interfaces_IApplicationWidget {

   public function __construct($options = array()) {
   }

   public function render($bEcho = true) {
      $module = App::Get ()->loadModule ();

      $str = '';
      $str .= '<div class="top">';
      $str .= '<h3>Data Browse</h3>';
      $str .= '<div class="product-type">';
      $str .= '<a href="javaScript:void(0);" onclick="displayProductTypes();">Show Product Types</a>';
      $str .= '</div>';
      $str .= '</div>';
      $str .= '<p class="generated-timestamp">Information generated as of: <span id="current-date"></span></p>';

      if ($bEcho) {
         echo $str;
      } else {
         return $str;
      }
   }
}
?>
