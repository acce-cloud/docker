/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
var intervalId;
$(document).ready(function() {
  getNodes();
  $('#auto-refresh').click(function() {
    if($(this).val() == "Enable Auto Refresh") {
      $(this).val("Disable Auto Refresh");
      intervalId = setInterval(function(){ getNodes(); }, refreshRate);
    } else {
      $(this).val("Enable Auto Refresh");
      clearInterval(intervalId);
    }
  });
});

/**
 * Retrieves queue and node relationship from web service.
 */
function getNodes() {
  $("#current-date").text((new Date()).toUTCString());

  $.getJSON( WORKFLOW_NODE_URL, function( data ) {
    data.nodes.sort(function(a, b){
      if (a.ID < b.ID) return -1;
      if (a.ID > b.ID) return 1;
      return 0;
    });
    var queues = {};
    $.each(data.nodes, function( i, value ) {
      if (value["Queue Lists"] != "") {
      var queueLists = value["Queue Lists"].split(",");
      $.each(queueLists, function( j,  queue) {
          if (queue in queues) {
        	  queues[queue].push(value.ID);
          } else {
        	  queues[queue] = [value.ID];
          }
        });
      }
    });
    getClusterReport(queues);
  });
}

/**
 * Retrieves current load for each node from web service and builds charts.
 *
 * @param queues
 *            mapping of queue to nodes
 */
function getClusterReport(queues) {
  var queueNames = Object.keys(queues).sort();
  var numRows = Math.round(queueNames.length / 2);
  var maxCapacity = 0;
  $.getJSON( WORKFLOW_CLUSTER_REPORT_URL, function( data ) {
    var nodes = {};
    $.each(data.nodes, function( index, value ) {
      nodes[value.ID] = {"Load": value.Load, "Free": value.Capacity - value.Load};
      if (value.Capacity > maxCapacity) {
        maxCapacity = value.Capacity;
      }
    });

    if ($("#charts").children().length == 0) {
      var table = $("<table>").attr("class", "chart");;
      table.append($("<tr>").append($("<td>").attr("class", "chart-container")).append($("<td>").attr("class", "chart-container")));
      
      $("#charts").append(table);
      var i = 0;
      var row;
      $.each(queueNames, function( i, key ) {
        if (i < numRows) {
          row = $("<tr>").attr("id", i);
          table.append(row);
        } else {
          row = $('#' + (i - numRows));
        }
        var d1 = [];
        var d2 = [];
        var label = [];
        $.each(queues[key], function( index, node ) {
          d1.push([index, nodes[node].Load]);
          d2.push([index, nodes[node].Free]);
          label.push([index, node]);
        });
  
        var cell = $("<td>").attr("class", "chart-container");
        cell.append($("<div>").attr("class", "title").append($("<h5>").text("Node Usage for " + key.replace(/([a-z])([A-Z])/g, "$1 $2"))));
  
        var chart = $("<div>").attr("class", "chart").attr("id", key);
        cell.append(chart);
        
        row.append(cell);
  
        createChart(chart, d1, d2, label, maxCapacity);
        i++;
      });
    } else {
      $.each(queueNames, function( i, key ) {
        var d1 = [];
        var d2 = [];
        var label = [];
        $.each(queues[key], function( index, node ) {
          d1.push([index, nodes[node].Load]);
          d2.push([index, nodes[node].Free]);
          label.push([index, node]);
        });
        createChart($('#' + key), d1, d2, label, maxCapacity);
      });
    }
  });
}

/**
 * Builds bar chart.
 *
 * @param chart
 *            div that holds chart
 * @param d1
 *            array of node used values
 * @param d2
 *            array of node free values
 * @param label
 *            array of node names
 * @param maxCapacity
 *            maximum capacity value of all nodes
 */
function createChart(chart, d1, d2, label, maxCapacity) {
  var series = [{
      data: d1,
      label: "Used"
    },
    {
      data: d2,
      label: "Free"
    }];

  var options = {
    grid: { hoverable: true},
    xaxis: {
      tickLength: 0,
      labelHeight: 45,
      ticks: label
    },
    yaxis: {
      labelWidth: 30,
      ticks: 8,
      min: 0,
      max: maxCapacity + 1,
      tickDecimals: 0
    },
    series: {
      bars: {
        show: true,
        barWidth: 0.6,
        align: "center",
        fill: 0.7
      },
      stack: true
    }
  };

  $.plot(chart, series, options);
  var xaxisLabelName = d1.length > 1 ? d1.length + " Nodes " : d1.length + " Node";
  var xaxisLabel = $("<div class='axisLabel xaxisLabel'></div>").text(xaxisLabelName).appendTo(chart);
  var yaxisLabel = $("<div class='axisLabel yaxisLabel'></div>").text("Number of Processes").appendTo(chart);
  yaxisLabel.css("margin-top", yaxisLabel.width() / 2 - 20);

  var previousPoint = [0,0,0];
  chart.bind("plothover", function (event, pos, item) {
    if (item) {
      if (previousPoint[0] != item.datapoint[0] || previousPoint[1] != item.datapoint[1] || previousPoint[2] != item.datapoint[2]) {
        previousPoint = item.datapoint;
        $("#tooltip").remove();
        var x = item.datapoint[0],
        y = item.datapoint[1] - item.datapoint[2],
        total = d1[item.dataIndex][1] + d2[item.dataIndex][1];
        nodeName = item['series']['xaxis']['ticks'][item['dataIndex']]['label'];
        showTooltip(item.pageX, item.pageY, "<p align=\"center\">" + nodeName + "</p>" + y + " " + item.series.label + " / " + total + " Total");
      }
    } else {
      $("#tooltip").remove();
      previousPoint = [0,0,0];            
    }
  });
}

/**
 * Creates tooltip to show value of bar.
 *
 * @param x
 * @param y
 * @param contents
 *            text to display
 */
function showTooltip(x, y, contents) {
  $('<div id="tooltip">' + contents + '</div>').css( {
    position: 'absolute',
    display: 'none',
    top: y + 5,
    left: x + 5,
    border: '1px solid #fdd',
    padding: '2px',
    'background-color': '#fee',
    opacity: 0.80
  }).appendTo("body").fadeIn(200);
}
