<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>
<div class="top">
<h3>Processing Monitor</h3>
<div class="definition">
   <a href="javaScript:void(0);" onclick="displayWorkflowDefinitions();">Show Workflow Definitions</a>
</div>
</div>
<p class="current">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>

<div class="temporal-search">
   <form id="temporal-search-form" action="" method="get">
   <fieldset>
   <legend class="expand" onclick="toggleFilters(this);">Filters</legend>
   <div>
   <table class="form">
   <tr>
      <td><label>Workflow Started Between</label></td>
      <td>
      <input type="text" class="temporal-start" />
      <input type="hidden" class="hidden-temporal-start" name="start" />
      <label>and</label>
      <input type="text" class="temporal-end" />
      <input type="hidden" class="hidden-temporal-end" name="end" />
      </td>
   </tr>
   <tr>
      <td><label>Orbit Number Between</label></td>
      <td>
         <input type="text" name="startOrbitNumber" />
         <label>and</label>
         <input type="text" name="stopOrbitNumber" />
      </td>
   </tr>
   <tr>
      <td><label>Status</label><br/>
         <button class="status" type="button" onclick="selectAllStatus(true);">Select All</button>
         <button type="button" class="status" onclick="selectAllStatus(false);">Unselect All</button>
      </td>
      <td>
         <table>
            <tr>
               <td><input class="checkbox" type="checkbox" name="status" value="STARTED">STARTED</td>
               <td><input type="checkbox" name="status" value="QUEUED">QUEUED</td>
               <td><input type="checkbox" name="status" value="CREATED">CREATED</td>
               <td><input type="checkbox" name="status" value="PRECONDITION_PASSED">PRECONDITION_PASSED</td>
               <td><input type="checkbox" name="status" value="PRECONDITION_FAILED">PRECONDITION_FAILED</td>
               <td><input type="checkbox" name="status" value="JOB_SENT">JOB_SENT</td>
               <td><input type="checkbox" name="status" value="RUNNING">RUNNING</td>
            </tr>
            <tr>
               <td><input class="checkbox" type="checkbox" name="status" value="PROCESSED">PROCESSED</td>
               <td><input type="checkbox" name="status" value="PROCESS_FAILED">PROCESS_FAILED</td>
               <td><input type="checkbox" name="status" value="PAUSED">PAUSED</td>
               <td><input type="checkbox" name="status" value="RESUMED">RESUMED</td>
               <td><input type="checkbox" name="status" value="STOPPED">STOPPED</td>
               <td><input type="checkbox" name="status" value="KILLED">KILLED</td>
               <td><input type="checkbox" name="status" value="FINISHED">FINISHED</td>
            </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td>Node Name</td>
      <td><select name="node"></select></td>
   </tr>
   <tr>
      <td>Workflow Name</td>
      <td><select name="workflow" data-placeholder="Choose a Workflow..." multiple class="chosen-select"></select></td>
   </tr>
   <tr>
      <td>Current Task Name</td>
      <td><select name="task"></select></td>
   </tr>
   <tr>
      <td>Processing Mode</td>
      <td>
         <input class="checkbox" type="checkbox" name="processing" value="forward">forward
         <input type="checkbox" name="processing" value="reprocessing">reprocessing
      </td>
   </tr>
      <tr>
      <td colspan="2"><input type="checkbox" name="byDuration" value="true" class="duration">Retrieve by Longest Duration</td>
   </tr>
   </table>
   <br/>
   <button class='temporal-search-button' type="submit">Apply</button>
   <button onclick="window.location='<?php echo SITE_ROOT?>/processing/index.php'; return false;">Reset</button>
   </div>
   </fieldset>
   </form>
</div>

<table id="processing-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Workflow ID</th>
         <th>Parent ID</th>
         <th>Workflow Name</th>
         <th>Half Orbit</th>
         <th>Progress</th>
         <th>Status</th>
         <th>Error Message</th>
         <th>Workflow Start Time</th>
         <th>Workflow Duration (Minutes)</th>
         <th>Pid</th>
         <th>Node Name</th>
         <th>Processing Mode</th>
         <th>Trigger Value</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
