<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>

<h3>Product Accountability</h3>
<p class="generated-timestamp">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>
<div id="tabs">
   <ul>
      <li><a href="#half-orbit-summary">Half-Orbit Products</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/dailySummary/index.php">Daily L3 Products</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbit/index.php">Half-Orbit Info</a></li>
   </ul>
   <div id="half-orbit-summary">
<?php 
$module = App::Get()->loadModule();
require_once($module->modulePath . "/scripts/widgets/HalfOrbitFilterWidget.php");

$filterWidget = new HalfOrbitFilterWidget(array('temporalLabel' => "Last Modified Date Time"));
$filterWidget->render();
?>
<br />
<table id="half-orbit-summary-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Half Orbit</th>
         <th>Radar Data Status</th>
         <th>Radiometer Data Status</th>
         <th>Half Orbit Start Date Time</th>
         <th>Last Modified</th>
         <th>L0BA</th>
         <th>L1AA</th>
         <th>CALST</th>
         <th>L1BS0</th>
         <th>L1CS0</th>
         <th>L0BP</th>
         <th>L1AP</th>
         <th>L1BTB</th>
         <th>L1BTBE</th>
         <th>L1CTB</th>
         <th>L1CTBE</th>
         <th>L2SMA</th>
         <th>L2SMP</th>
         <th>L2SMPE</th>
         <th>L2SMAP</th>
         <th>L2FTA</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
</br>
<p><span class="running">R</span> = Running, <span class="failed">F</span> = Failed</p>
</div>
</div>
