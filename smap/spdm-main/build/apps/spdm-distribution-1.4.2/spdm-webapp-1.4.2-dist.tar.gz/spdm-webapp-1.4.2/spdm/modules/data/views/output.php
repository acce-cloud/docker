<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

$dataBrowseHeaderWidget = new DataBrowseHeaderWidget();
$dataBrowseHeaderWidget->render();
?>
<div id="tabs">
   <ul>
      <li><a href="<?php echo SITE_ROOT?>/data/incoming/index.php">Incoming Data</a></li>
      <li><a href="#output">Output Data</a></li>
      <li><a href="<?php echo SITE_ROOT?>/data/all/index.php">All Data</a></li>
   </ul>
   <div id="output">
<?php
$temporalFilterWidget = new TemporalFilterWidget ();
$temporalFilterWidget->render ();
?>
      <br />
      <table id="output-table" class="tablesorter">
         <thead>
            <tr>
               <th></th>
               <th>Product Type</th>
               <th>Number of Files</th>
            </tr>
         </thead>
         <tbody>
         </tbody>
      </table>
   </div>
</div>
