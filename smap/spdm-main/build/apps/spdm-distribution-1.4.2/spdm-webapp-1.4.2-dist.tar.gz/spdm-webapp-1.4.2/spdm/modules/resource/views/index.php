<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>

<div class="top">
<h3>Resource Monitor</h3>
<div class="ganglia">
   <a href="<?php echo App::Get()->settings['ganglia'];?>">Ganglia</a>
</div>
</div>
<p class="current">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>

<div id="charts"></div>
