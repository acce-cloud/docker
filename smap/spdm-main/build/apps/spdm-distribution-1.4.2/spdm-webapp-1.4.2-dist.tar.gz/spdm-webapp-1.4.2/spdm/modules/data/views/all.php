<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

$dataBrowseHeaderWidget = new DataBrowseHeaderWidget();
$dataBrowseHeaderWidget->render();
?>
<div id="tabs">
   <ul>
      <li><a href="<?php echo SITE_ROOT?>/data/incoming/index.php?range=today">Incoming Data</a></li>
      <li><a href="<?php echo SITE_ROOT?>/data/output/index.php?range=today">Output Data</a></li>
      <li><a href="#all">All Data</a></li>
   </ul>
   <div id="all">
   <div class="product-search">
      <form id="product-search-form" action="" method="get">
         <table class="form">
            <tr><td><label for="product-type">Product Type</label></td><td><input id="product-type" name="type" /></td></tr>
            <tr id="column"><td><label for="column">Columns</label></td><td><select name="column" data-placeholder="Choose a Column..." multiple class="chosen-select"></select></td></tr>
         </table>
   		 <div id="filter">
   	        <p class="label">Filters</p>
   	        <table id="filter-table" class="filter"></table>
   		 </div>
         <input type="hidden" class="hidden-filter" name="filter" />
   		<div>
           <button class='temporal-search-button' type="submit">Apply</button>
           <button onclick="window.location=window.location.pathname; return false;">Reset</button>
   		</div>
      </form>
   </div>
   <table id="data-table" class="tablesorter">
      <thead>
         <tr>
            <th></th>
            <th>Product Type</th>
            <th>Product Name</th>
            <th>Product Received Time</th>
            <th>Transfer Status</th>
            <th>Workflow ID</th>
         </tr>
      </thead>
      <tbody>
      </tbody>
   </table>
   </div>
</div>
