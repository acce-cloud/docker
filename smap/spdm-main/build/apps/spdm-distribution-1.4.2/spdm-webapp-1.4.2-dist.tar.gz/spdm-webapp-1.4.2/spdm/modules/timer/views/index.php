<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>
<h3>Timer Monitor</h3>
<p class="generated-timestamp">Information generated as of: <span id="current-date"></span></p>

<form id="temporal-form" action="" method="get">
<table class="form">
   <tr>
      <td>Start Time&nbsp;</td>
      <td>
         <div id="temporal-range">
         <input onchange="this.form.submit();" type="radio" id="temporal-1" name="range" value="today"><label for="temporal-1">Today</label>
         <input onchange="this.form.submit();" type="radio" id="temporal-2" name="range" value="yesterday"><label for="temporal-2">Yesterday</label>
         <input onchange="this.form.submit();" type="radio" id="temporal-3" name="range" value="thisMonth"><label for="temporal-3">This Month</label>
         <input onchange="this.form.submit();" type="radio" id="temporal-4" name="range" value="lastMonth"><label for="temporal-4">Last Month</label>
         </div>
         <span>or between</span>
         <input type="text" class="temporal-start" />
         <input type="hidden" class="hidden-temporal-start" name="start" />
         <span>and</span>
         <input type="text" class="temporal-end" />
         <input type="hidden" class="hidden-temporal-end" name="end" />
      </td>
   </tr>
   <tr>
      <td><label>Status</label><br/>
         <button class="status" type="button" onclick="selectAllStatus(true);">Select All</button>
         <button type="button" class="status" onclick="selectAllStatus(false);">Unselect All</button>
      </td>
      </td>
      <td>
         <table>
            <tr>
               <td><input class="checkbox" type="checkbox" name="status" value="started"><span title="Status set for timer that was started by timer launcher or manually.">started</span></td>
               <td><input type="checkbox" name="status" value="stopped"><span title="Status set for timer that was stopped manually.">stopped</span></td>
               <td><input type="checkbox" name="status" value="expired"><span title="Status set for timer at expiration; Timer exited without further action.">expired</span></td>
               <td><input type="checkbox" name="status" value="processed"><span title="Status set for timer that found generated product; Timer exited without further action.">processed</span></td>
               <td><input type="checkbox" name="status" value="processed_failed"><span title="Status set for timer that found attempted but failed processing previously; Timer exited without further action.">processed_failed</span></td>
               <td><input type="checkbox" name="status" value="wf_triggered"><span title="Status set for timer that found primary pre-conditions ready then triggered processing.">wf_triggered</span></td>
            </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td><label>Expire Time Between</label></td>
      <td>
      <input type="text" class="expire-temporal-start" name="expireStart" />
      <label>and</label>
      <input type="text" class="expire-temporal-end" name="expireEnd" />
      </td>
   </tr>
   <tr>
      <td><label>Orbit Number Between</label></td>
      <td>
         <input type="text" name="startOrbitNumber" />
         <label>and</label>
         <input type="text" name="stopOrbitNumber" />
      </td>
   </tr>
   <tr>
      <td><label>Half Orbit Date Time Between</label></td>
      <td>
      <input type="text" class="orbit-temporal-start" name="orbitStart" />
      <label>and</label>
      <input type="text" class="orbit-temporal-end" name="orbitEnd" />
      </td>
   </tr>
   <tr>
      <td><label>Timer Name</label></td>
      <td><select name="name" data-placeholder="Choose a Timer..." multiple class="chosen-select"></select></td>
   </tr>
</table>
<button class="temporal-search-button" type="submit">Apply</button>
<button onclick="window.location=window.location.pathname; return false;">Reset</button>
</form>
<br />
<table id="data-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Half Orbit</th>
         <th>Half Orbit Start Date Time</th>
         <th>Timer Name</th>
         <th>Start Time</th>
         <th>Expire Time</th>
         <th>Status</th>
         <th>Input Names</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
