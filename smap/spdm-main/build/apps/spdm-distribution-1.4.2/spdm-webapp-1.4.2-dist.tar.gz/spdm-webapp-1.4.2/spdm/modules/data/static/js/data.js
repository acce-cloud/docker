/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
var gdsOnly = false;
$(document).ready(function() {
  var columns = [ { "mData": null },
                  { "mData": "ProductType" },
                  { "mData": "FileName" },
                  { "mData": "ProductReceivedTime" },
                  { "mData": "ProductTransferStatus" },
                  { "mData": "WFID", "sType": "numeric_ignore_nan" }
                ];

  $("#current-date").text((new Date()).toUTCString());

  var tabIndex = 0;
  if ($("#output-table").length) {
    tabIndex = 1;
  } else if ($("#data-table").length) {
    tabIndex = 2;
  }
  createDataBrowseTabs(tabIndex);

  //Parse query parameters
  var queryParameters = getQueryParameters();
  var type = queryParameters["type"];
  var filter = queryParameters["filter"];
  var range = queryParameters["range"];
  var start = queryParameters["start"];
  var end = queryParameters["end"];
  var column = queryParameters["column"];
  
  if ($("#incoming-table").length) {
    var gds = queryParameters["gds"];
    if (gds && "true" === gds) {
      gdsOnly = true;
      $("input[name=gds]").attr('checked', true);
    }
    getIncomingSummary(range, start, end);
  } else if ($("#output-table").length) {
    getOutputSummary(range, start, end);
  } else if ($("#data-table").length) {

  var productUrl = PRODUCT_URL;

  // Build query string request to send to web service
  var queryString = [];
  if (type) { // Product type is required for filter query
    var params = {productType: type, order: "DESC", orderBy: "ProductReceivedTime"};

    $("#product-type").val(type);
    populateProductMetadataKeys(type, column);
    $("#filter").show();
    queryString.push("1=1");

    if (filter) {
      var filters = filter.split(",");
      $.each(filters, function( index, value ) {
        var operator;
        if (value.indexOf(">=") != -1) {
          operator = ">=";
        } else if (value.indexOf("<=") != -1) {
          operator = "<=";
        } else if (value.indexOf("=") != -1) {
          operator = "=";
        }
        if (operator) {
          var keyValue = value.split(operator);
          addExistingFilter(keyValue[0], keyValue[1], operator);

          var formattedValue = keyValue[1];
          if (keyValue[0].match(/Time$/i)) {
            formattedValue = keyValue[1];
          }
        
          // For ProductReceivedTime send as minPrt or maxPrt as required by web service
          if (keyValue[0] == "ProductReceivedTime") {
          	if (operator == ">=") {
              params["minPrt"] = formattedValue;
          	} else if (operator == "<=") {
          	  params["maxPrt"] = formattedValue; 		
          	} else if (operator == "="){
          		//TODO web service currently does not support =
          	}
          } else {
            if (formattedValue.indexOf("*") != -1) {
              //Replace * with %
              formattedValue = formattedValue.replace(/\*/g, '%');
              queryString.push(keyValue[0] + " like ''" + formattedValue);
            } else {
              queryString.push(keyValue[0] + operator + formattedValue);
            }
          }
        }
      });
    }

    params["queryString"] = "'" + queryString.join(" and ") + "'";

    // Web service does not allow minPrt without maxPrt and vice versa
    if ("minPrt" in params || "maxPrt" in params) {
    	productUrl += "prt/";
    	if ("minPrt" in params && !("maxPrt" in params)) {
    		params["maxPrt"] = "2100-01-01T00:00:00";
    	}
    	else if ("maxPrt" in params && !("minPrt" in params)) {
    		params["minPrt"] = "1900-01-01T00:00:00";
    	}
    }
    
    if (column) {
      // Add dynamic columns
      if (column instanceof Array) {
        $.each(column, function( index, value ) {
          $('#data-table').children('thead').children('tr:first').append($("<th>").text(value));
          columns.push({ "mData": 'curkey' + index });
        });
      } else {
        $('#data-table').children('thead').children('tr:first').append($("<th>").text(column));
        columns.push({ "mData": 'curkey0' });
      }
      params["column"] = column;
    }
    
    productUrl += "q?" + jQuery.param( params, true );
  }

  createDataTable("#data-table",
    [[ 3, "desc" ]],
    [
     { "bSortable": false, "aTargets": [ 0 ] },
     { 
      "mData": 2,
      "aTargets": [ 2 ],
      "mRender": function ( data, type, full ) {
        if ( type === 'display' ) {
          return '<a href="javaScript:void(0);" onclick="displayMetadata(\''+data+'\');">'+data+'</a>';
        } else {
          return data;
        }
      }
    }],
    productUrl,
    columns,
    "products", true
  );

  $.ajax({
    type: "GET",
    url: PRODUCT_TYPE_URL,
    dataType: "json",
    cache: false,
    success: function(data) {
      data.producttypes.sort();
      $("#product-type").autocomplete({
        source: function(req, responseFn) {
          var re = $.ui.autocomplete.escapeRegex(req.term);
          var matcher = new RegExp( "^" + re, "i" );
          var a = $.grep( data.producttypes, function(item,index){
            return matcher.test(item);
          });
          responseFn( a );
        }
      });
    },
    error: function(xhr, status, error) {
    }
  });

  $("#product-search-form").submit(function(event){
    if ($("#product-type").val()) {
      var filterString = "";
      $('#filter-table tr').not(":last").each(function(){
        $(this).find('td').not(":last").each(function(){
          filterString += $(this).text();
        });
        filterString += ",";
      });
      $(".hidden-filter").val(filterString.slice(0,-1));
    }
  });
  }
});

function createMetadataSelect(metadata) {
  var metadataSelect = $("<select>");
  metadataSelect.append($("<option>").text("Choose One").val(""));
  $.each(metadata.sort(), function( index, value ) {
    if (metadataKeysExclusion.indexOf(value) == -1) {
      metadataSelect.append($("<option>").text(value).val(value));
    }
  });
  metadataSelect.change(function() { 
    $( this ).next().next().val("")
    if ($( this ).val().match(/Time$/i)) {
      createDateTimePicker($( this ).parent().next().next().children(":first"), null);
    } else {
      $( this ).parent().next().next().children(":first").datetimepicker("destroy");
    }
  });
  return metadataSelect;
}

function createOperatorSelect() {
  var operatorSelect = $("<select>");
  operatorSelect.append($("<option>").text("=").val("="));
  operatorSelect.append($("<option>").text(">=").val(">="));
  operatorSelect.append($("<option>").text("<=").val("<="));
  return operatorSelect;
}

/**
 * Populates filter selection with product type metadata keys retrieved from web
 * service. Note this makes a blocking (synchronous) call to web service.
 *
 * @param productType
 *            product type to retrieve metadata keys
 */
function populateProductMetadataKeys(productType, column) {
  $.ajax({
    type: "GET",
    url: PRODUCT_TYPE_KEY_URL + productType,
    dataType: "json",
    async: false,
    success: function(data) {
      populateColumnsSelect(data.keys, column);
      var row = $("<tr>");
      row.append($("<td>").append(createMetadataSelect(data.keys)));
      row.append($("<td>").append(createOperatorSelect()));
      row.append($("<td>").append($("<input>")));
      row.append($("<td>").append($("<button>").attr("type", "button").text("Add").click(function () {
        var value = $( this ).parent().prev().children(":first").val();
        var operator = $( this ).parent().prev().prev().children(":first").val();
        var key = $( this ).parent().prev().prev().prev().children(":first").val();
        if (value != "" && key != "") {
          addExistingFilter(key, value, operator);
          $( this ).parent().prev().remove();
          $( this ).parent().prev().remove();
          $( this ).parent().prev().remove();

          $( this ).parent().parent().prepend($("<td>").append($("<input>")));
          $( this ).parent().parent().prepend($("<td>").append(createOperatorSelect()));
          $( this ).parent().parent().prepend($("<td>").append(createMetadataSelect(data.keys)));
        }
      })));
      $("#filter-table").append(row);
    },
    error: function(xhr, status, error) {
    }
  });
}

function populateColumnsSelect(metadata, column) {
  $("#column").show();
  var select = $("select[name=column]");
  $.each(metadata, function( index, value ) {
    if (columnKeysExclusion.indexOf(value) == -1) {
      select.append($("<option>").text(value).val(value));
    }
  });
  select.val(column);
  select.chosen();
}

/**
 * Adds new row to filter table with specified key, value, operator.
 *
 * @param key
 *            metadata key
 * @param value
 *            metadata value
 * @param operator =,
 *            >=, <=
 */
function addExistingFilter(key, value, operator) {
  var row = $("<tr>");
  row.append($("<td>").text(key));
  row.append($("<td>").text(operator));
  row.append($("<td>").text($.trim(value)));
  row.append($("<td>").append($("<button>").attr("type", "button").text("Remove").click(function () {
    $( this ).parent().parent().remove();    
  })));
  $("#filter-table tr:last").before(row);
}

function getIncomingSummary(range, start, end) {
  instantiateTemporalFilterWidget(range, start, end);

  var summaryUrl = getSummaryUrl(spdmWsUrl + "/incomingsummary/q?", range, start, end, "startDate", "stopDate");
  createDataTable("#incoming-table",
    [[ 1, "asc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
      {
        "mData": 1,
        "aTargets": [ 1 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            if (data == "N/A") {
              return data;
            } else {
              return '<a href="javaScript:void(0);" onclick="redirectToAllData(\''+data+'\',\'' + range + '\',\'' + start + '\',\'' + end + '\');">'+data+'</a>';
            }
          } else {
            return data;
          }
        }
    }],
    summaryUrl,
    [ 
      { "mData": null },
      { "mData": "ProdType" },
      { "mData": "Count" },
    ],
    "products",
    false,
    false,
    -1,
    processIncomingSummary
  );
}

function getOutputSummary(range, start, end) {
  instantiateTemporalFilterWidget(range, start, end);

  var summaryUrl = getSummaryUrl(spdmWsUrl + "/genprodsummary/q?", range, start, end, "startDate", "stopDate");
  createDataTable("#output-table",
    [[ 1, "asc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
      {
        "mData": 1,
        "aTargets": [ 1 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            if (data == "N/A") {
              return data;
            } else {
              return '<a href="javaScript:void(0);" onclick="redirectToAllData(\''+data+'\',\'' + range + '\',\'' + start + '\',\'' + end + '\');">'+data+'</a>';
            }
          } else {
            return data;
          }
        }
    }],
    summaryUrl,
    [ 
      { "mData": null },
      { "mData": "ProdType" },
      { "mData": "Count" },
    ],
    "products",
    false,
    false,
    -1,
    displayTotalNumberOfFiles
  );
}

function redirectToAllData(productType, range, start, end) {
  var timeRange = getProductReceivedTimeRange(range, start, end, "startTime", "stopTime");
  var params = {"type": productType};
  var filter = "";
  if ("startTime" in timeRange) {
    filter += "ProductReceivedTime>=" + timeRange["startTime"];
  }
  if ("stopTime" in timeRange) {
    if (filter != "") {
      filter += ",";
    }
    filter += "ProductReceivedTime<=" + timeRange["stopTime"];
  }
  params["filter"] = filter;
  window.location = "../all/index.php?" + jQuery.param( params );
}

/**
 * Displays dialog box listing product types.
 */
function displayProductTypes() {
  $.getJSON( PRODUCT_TYPE_URL, function( data ) {
    data.producttypes.sort();
    var table = $("<table>").attr("class", "product-type");
    var row;
    $.each(data.producttypes, function( index, value ) {
      if (index % 3 == 0) {
        row = $("<tr>");
        table.append(row);
      }
      row.append($("<td>").append($("<a>")
          .text(value)
          .attr("class", "product-type-link")
          .attr("href", "javaScript:void(0);")
          .attr("onclick", "displayProductTypeMetadata('" + value + "');")));
    });
    var div = $("<div>");
    div.attr("title", "Product Types");
    div.append(table);
    div.dialog({
      width: 800,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

/**
 * Displays dialog box listing valid metadata keys for specified product type.
 * @param productType
 */
function displayProductTypeMetadata(productType) {
  $.getJSON( PRODUCT_TYPE_KEY_URL + productType, function( data ) {
    var list = $("<ul>");
    $.each(data.keys, function( index, value ) {
      var listItem = $("<li>").text(value);
      list.append(listItem);
    });
    var div = $("<div>");
    div.attr("title", "Metadata Keys for " + productType);
    div.append(list);
    div.dialog({
      width: 500,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

/**
 * Diplay summation of number of files per product type returned.
 * @param json
 */
function displayTotalNumberOfFiles(json) {
  var sum = 0;
  $.each(json.products, function( index, value ) {
    sum += value.Count;
  });
  var totalText = sum + " Total Number of Files Ingested";
  if ($("div.total-count").length) {
    $("div.total-count").text(totalText);
  } else {
    $("div.fg-toolbar").append($("<div>").text(totalText).attr("class", "total-count"));
  }
}

/**
 * Creates tabs specifically for Data Browse.
 *
 * @param tabIndex
 *          index of selected tab
 */
function createDataBrowseTabs(tabIndex) {
  $("#tabs").tabs({
    beforeActivate : function(event, ui) {
      if ($(ui.newTab).find('a').attr('href').indexOf('#') != 0) {
        //if current active tab or clicked tab is All Data
        //then do not pass any query parameters
        if (tabIndex === 2 || $(ui.newTab).find('a').attr('id') === "ui-id-3") {
          window.open($(ui.newTab).find('a').attr('href'), '_self');
        } else {
          window.open($(ui.newTab).find('a').attr('href') + window.location.search, '_self');
        }
      }
    },
    active : tabIndex
  });
}

/**
 * Preprocesses JSON data for incoming summary tab.
 * @param json
 */
function processIncomingSummary(json) {
  if (gdsOnly) {
    for(var i = json.products.length -1; i >= 0 ; i--){
        if (gdsProductTypes.indexOf(json.products[i].ProdType) === -1) {
          json.products.splice(i, 1);
      }
    }
  }
  displayTotalNumberOfFiles(json);
}
