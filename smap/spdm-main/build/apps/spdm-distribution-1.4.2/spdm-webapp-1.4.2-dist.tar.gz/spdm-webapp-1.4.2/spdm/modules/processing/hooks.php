<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

/**
 * HOOKS.PHP
 *
 * Hooks provide the ability, as the name implies, to hook into various parts of
 * the view rendering process and insert customizations. The contents of these
 * functions are run at the appropriate time *EVERY* time a view is rendered, i.e.
 * the content of the hooks is not by default view-specific but rather will be
 * applied to all views. (However, there is nothing that prevents developers from
 * inserting conditional logic inside a hook that then causes view-specific
 * them to exhibit view-specific behavior).
 *
 * As an example, consider a hook that adds the amount of time Balance took to render
 * the page as an inline HTML comment at the bottom of each page after it has been sent:
 *
 * function hook_after_send() {
 *     $timeStart = $GLOBALS['balance_request_start'];
 *     $timeNow   = microtime(true);
 *     $elapsed   = $timeNow - $timeStart;
 *     echo "<!-- page rendered in {$elapsed} seconds -->";
 * }
 *
 *
 * Take a look at the docblock descriptions of each hook to get a sense of where
 * in the view rendering process the hook is invoked.
 *
 */

/**
 * hook_before_all
 *
 * This hook is executed before any other hooks. It can be used for any
 * pre-processing logic.
 */
function hook_before_all() {}

/**
 * hook_before_header
 *
 * This hook is executed before the contents of the header file are processed.
 */
function hook_before_header() {}

/**
 * hook_before_view
 *
 * This hook is executed before the contents of the main view are processed.
 */
function hook_before_view() {
	require_once( 'scripts/widgets/BreadcrumbsWidget.php' );

	$module = App::Get()->loadModule();
	// Include JavaScript files to be shown with every view in this module

	// Global configuration values
	$js = "var siteStaticUrl = '" . SITE_ROOT . "/static'\r\n"
		. "    spdmWsUrl = '" . trim(App::Get()->settings['spdm_ws_url']) ."'\r\n"
		. "    refreshRate = " . trim(App::Get()->settings['refresh_rate']) .";\r\n";
	App::Get()->response->addJavascript( $js, true ); // raw Javascript

	// Third-party JavaScript files
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/jquery-1.10.2.min.js');
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/jquery-ui-1.10.3.custom.min.js');
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/jquery.dataTables.min.js');
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/dataTables.fnReloadAjax.js');
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/jquery-ui-timepicker-addon.js');
	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/chosen.jquery.min.js');

	App::Get()->response->addJavascript(SITE_ROOT.'/static/js/common.js');
	App::Get()->response->addJavascript($module->moduleStatic.'/js/processing.js');

	// Include CSS stylesheets to be shown with every view in this module

	// Third-party CSS stylesheets
	App::Get()->response->addStylesheet(SITE_ROOT.'/static/css/smoothness/jquery-ui-1.10.3.custom.min.css');
	App::Get()->response->addStylesheet(SITE_ROOT.'/static/css/jquery.dataTables_themeroller.css');
	App::Get()->response->addStylesheet(SITE_ROOT.'/static/css/jquery-ui-timepicker-addon.css');
	App::Get()->response->addStylesheet(SITE_ROOT.'/static/css/chosen.min.css');

	App::Get()->response->addStylesheet($module->moduleStatic.'/css/processing.css');
}

/**
 * hook_before_footer
 *
 * This hook is executed before the contents of the footer are processed
 */
function hook_before_footer() {}

/**
 * hook_before_send
 *
 * This hook is after all of the view components (header, view, footer) have been
 * processed but before the processed results are sent out across the wire to the
 * browser. HTTP headers have not yet been sent to the browser.
 */
function hook_before_send() {}

/**
 * hook_after_send
 *
 * This hook is after all of the view components (header, view, footer) have been
 * processed and sent out across the wire to the browser. It can be used for logging
 * or analytics purposes, or to append a common trailer to all content.
 */
function hook_after_send() {}
