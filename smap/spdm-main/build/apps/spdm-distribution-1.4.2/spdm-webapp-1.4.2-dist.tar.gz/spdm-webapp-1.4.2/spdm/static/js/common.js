/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */

var SERVICE_STATUS_URL = spdmWsUrl + "/service/status";

var WORKFLOW_URL = spdmWsUrl + "/workflow/";
var WORKFLOW_DEF_URL = WORKFLOW_URL + "definition/";
var WORKFLOW_NODE_URL = WORKFLOW_URL + "node/";
var WORKFLOW_CLUSTER_REPORT_URL = WORKFLOW_URL + "clusterreport";
var WORKFLOW_EXECUTING_JOB_URL = WORKFLOW_URL + "executingjob";
var WORKFLOW_DETAILED_ERROR_URL = WORKFLOW_URL + "error/";

var PRODUCT_URL = spdmWsUrl + "/product/";
var PRODUCT_TYPE_URL = PRODUCT_URL + "type/";
var PRODUCT_TYPE_KEY_URL = PRODUCT_URL + "key/?type=";

var TIMER_URL = spdmWsUrl + "/timer/";
var TIMER_NAME_URL = TIMER_URL + "name/";

/**
 * Custom data table sorting function that sorts on numbers only and ignores string
 */
if ( jQuery.fn.dataTableExt ) {

jQuery.fn.dataTableExt.oSort['numeric_ignore_nan-asc']  = function(x,y) {
  if ((isNaN(x) && isNaN(y)) || (x === "" && y === "")) return ((x < y) ? -1 : ((x > y) ? 1 : 0));

  if (isNaN(x) || x === "") return 1;
  if (isNaN(y) || y === "") return -1;

  x = parseFloat( x );
  y = parseFloat( y );
  return ((x < y) ? -1 : ((x > y) ? 1 : 0));
};

jQuery.fn.dataTableExt.oSort['numeric_ignore_nan-desc'] = function(x,y) {
  if ((isNaN(x) && isNaN(y)) || (x === "" && y === "")) return ((x < y) ? 1 : ((x > y) ? -1 : 0));

  if (isNaN(x) || x === "") return 1;
  if (isNaN(y) || y === "") return -1;

  x = parseFloat( x );
  y = parseFloat( y );
  return ((x < y) ? 1 : ((x > y) ? -1 : 0));
};

jQuery.fn.dataTableExt.oSort['string_ignore_empty-asc']  = function(x,y) {
  if (x === "") return 1;
  if (y === "") return -1;
  return ((x < y) ? -1 : ((x > y) ? 1 : 0));
};

jQuery.fn.dataTableExt.oSort['string_ignore_empty-desc'] = function(x,y) {
  if (x === "") return 1;
  if (y === "") return -1;
  return ((x < y) ? 1 : ((x > y) ? -1 : 0));
};

jQuery.fn.dataTableExt.oSort['orbit-asc']  = function(a,b) {
  if (a == b) {
    return 0;
  } else if (a == 0) {
    return 1;
  } else if (b == 0) {
    return -1;
  } else {
    var xDigit = parseInt(a.substring(0, a.length - 1));
    var xChar = a.charAt(a.length - 1);

    var yDigit = parseInt(b.substring(0, b.length - 1));
    var yChar = b.charAt(b.length - 1);

    if (xDigit < yDigit) {
      return -1;
    } else if (xDigit > yDigit) {
      return 1;
    } else {
      return ((xChar < yChar) ? -1 : ((xChar > yChar) ?  1 : 0));
    }
  }
};

jQuery.fn.dataTableExt.oSort['orbit-desc'] = function(a,b) {
  if (a == b) {
    return 0;
  } else if (a == 0) {
    return 1;
  } else if (b == 0) {
    return -1;
  } else {
    var xDigit = parseInt(a.substring(0, a.length - 1));
    var xChar = a.charAt(a.length - 1);

    var yDigit = parseInt(b.substring(0, b.length - 1));
    var yChar = b.charAt(b.length - 1);

    if (xDigit < yDigit) {
      return 1;
    } else if (xDigit > yDigit) {
      return -1;
    } else {
      return ((xChar < yChar) ? 1 : ((xChar > yChar) ?  -1 : 0));
    }
  }
};

}
/**
 * Parses query string.
 *
 * @returns map containing query parameters
 */
function getQueryParameters() {
  var parameterMap = {};
  var parameters = window.location.search.substr(1).split('&');
  for (var i = 0; i < parameters.length; i++) {
    var parameter = parameters[i].split('=');
    var key = decodeURIComponent(parameter[0]);
    var value = decodeURIComponent(parameter[1]);
    if (key in parameterMap) {
      if (parameterMap[key] instanceof Array) {
        parameterMap[key].push(value);
      } else {
        var multiValue = [];
        multiValue.push(parameterMap[key]);
        multiValue.push(value);
        parameterMap[key] = multiValue;
      }
    } else {
      parameterMap[key] = value;
    }
  }
  return parameterMap;
}

/**
 * Creates date time picker.
 *
 * @param element
 *            input element for which to display date time picker
 * @param value
 *            initial value of date time picker
 * @param defaultHour
 *            value of hour slider
 * @param defaultMin
 *            value of minute slider
 * @param defaultSec
 *            value of second slider
 */
function createDateTimePicker(element, value, defaultHour, defaultMin, defaultSec) {
  var currentYear = new Date().getFullYear();
  element.datetimepicker({
    timeFormat: "HH:mm:ss",
    dateFormat: "yy-mm-dd",
    separator: "T",
    changeMonth: true,
    changeYear: true,
    yearRange: "2009:" + currentYear,
    hour: defaultHour,
    minute: defaultMin,
    second: defaultSec
  });
  if (value) {
    element.datetimepicker("setDate", toDateObject(value));
  }
}

/**
 * Creates date picker.
 *
 * @param element
 *            input element for which to display date time picker
 * @param value
 *            initial value of date time picker
 */
function createDatePicker(element, value) {
  var currentYear = new Date().getFullYear();
  element.datetimepicker({
    dateFormat: "yy-mm-dd",
    changeMonth: true,
    changeYear: true,
    yearRange: "2009:" + currentYear,
    showTimepicker: false
  });
  if (value) {
    element.datetimepicker("setDate", toDateObject(value));
  }
}

/**
 * Parses date time string of the format yy-mm-ddTHH:mm:ss to JavaScript date
 * object.
 *
 * @param value
 *            date time string
 * @returns JavaScript date object
 */
function toDateObject(value) {
  var date = $.datepicker.parseDate( "yy-mm-dd", value.substring(0, 10) );
  if (value.length > 10) {
  var time = $.datepicker.parseTime( "HH:mm:ss", value.substring(11, 19) );
  date.setHours(time.hour);
  date.setMinutes(time.minute);
  date.setSeconds(time.second);
  }
  return date;
}

/**
 * Creates data table.
 */
function createDataTable(elementId, sorting, columnDefs, ajaxSource, columns, ajaxDataProp, displayTotal, bPaginate, displayLength, callback) {
  if (!$.fn.DataTable.fnIsDataTable( document.getElementById(elementId.substr(1)) )) {
  $(elementId).dataTable({
    "aLengthMenu": [ 50, 100, 500, 1000 ],
    "sScrollX": "100%",
    "bFilter": false,
    "bInfo": false,
    "bJQueryUI": true,	
    "sPaginationType": "full_numbers",
    "bPaginate": typeof bPaginate === 'undefined' ? true : bPaginate,
    "iDisplayLength": typeof displayLength === 'undefined' ? 50 : displayLength,
    "bProcessing": true,
    "aaSorting": sorting,
    "aoColumnDefs": columnDefs,
    "sAjaxSource": ajaxSource,
    "aoColumns": columns,
    "sAjaxDataProp": ajaxDataProp,
    "fnServerData": function ( sSource, aoData, fnCallback, oSettings ) {
      oSettings.jqXHR = $.getJSON( sSource, aoData, function (json) { 
        //web service can return array with one empty JSON object so remove it
        if (json[ajaxDataProp].length == 1 && jQuery.isEmptyObject(json[ajaxDataProp][0])) {
          json[ajaxDataProp] = [];
        }
        if (callback) callback(json);
        fnCallback(json);
        if (displayTotal) {
        var recordsTotal = oSettings.fnRecordsTotal();
        var matchesTotal = recordsTotal;
        $.each(json, function( key, value ) {
          if (value.length > 0 && typeof(value[0].TotalCount) !== 'undefined') {
            matchesTotal = value[0].TotalCount;
          }
          return false;
        });
        var totalText = "Returned " + recordsTotal + " of " + matchesTotal + " Total Matches";
        if ($("div.total-count").length) {
          $("div.total-count").text(totalText);
        } else {
          $("div.fg-toolbar").append($("<div>").text(totalText).attr("class", "total-count"));
        }
        }
      });
    },
    "fnDrawCallback": function ( oSettings ) {
      /* Need to redo the counters if filtered or sorted */
      if ( oSettings.bSorted || oSettings.bFiltered ) {
        for ( var i=0, iLen=oSettings.aiDisplay.length ; i<iLen ; i++ ) {
          $('td:eq(0)', oSettings.aoData[ oSettings.aiDisplay[i] ].nTr ).html( i+1 );
        }
      }
    },
    "sDom": '<"top fg-toolbar ui-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix"lp>rt<"bottom fg-toolbar ui-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix"lp>'
  });
  }
  var divToAppendRefresh = $("div.fg-toolbar");
  if ($("div.dataTables_paginate").length) {
    divToAppendRefresh = $("div.dataTables_paginate");
  }
  divToAppendRefresh.append('<input class="refresh" alt="Refresh" src="' + siteStaticUrl + '/img/view_refresh.png" type="image" onclick="refresh($(\'' + elementId + '\'))"/>');
}

/**
 * Refreshes data table.
 */
function refresh(table) {
  if (typeof intervalId !== 'undefined') {
    clearInterval(intervalId);
  }

  var oTable = table.dataTable();
  oTable.fnReloadAjax(null, null, true);
  $("#current-date").text((new Date()).toUTCString());

  if (typeof intervalId !== 'undefined') {
    intervalId = setInterval(function(){ refresh(table); }, refreshRate);
  }
}

/**
 * Adds change event listener to auto-refresh checkbox.
 */
function addRefreshListener(table) {
  $('#auto-refresh').click(function() {
    if($(this).val() == "Enable Auto Refresh") {
      $(this).val("Disable Auto Refresh");
      intervalId = setInterval(function(){ refresh($(table)); }, refreshRate);
    } else {
      $(this).val("Enable Auto Refresh");
      clearInterval(intervalId);
    }
  });
}

/**
 * Creates tabs.
 *
 * @param tabIndex
 *          index of selected tab
 */
function createTabs(tabIndex) {
  $("#tabs").tabs({
    beforeActivate : function(event, ui) {
      if ($(ui.newTab).find('a').attr('href').indexOf('#') != 0) {
        window.open($(ui.newTab).find('a').attr('href') + window.location.search, '_self');
      }
    },
    active : tabIndex
  });
}

function instantiateTemporalFilterWidget(range, start, end, showDateOnly) {
  if (showDateOnly) {
    createDatePicker($('.temporal-start'), start);
    createDatePicker($('.temporal-end'), end);
  } else {
    createDateTimePicker($('.temporal-start'), start);
    createDateTimePicker($('.temporal-end'), end, 23, 59, 59);
  }

  $( "#temporal-range" ).buttonset();

  if (!start && !end) {
    $("input[name=range][value=" + range + "]").attr("checked", true);
    $( "#temporal-range" ).buttonset("refresh");
  }

  $("#temporal-form").submit(function(event){
    //TODO Disable search button unless there are values
    //TODO Check that start < end
    $(".hidden-temporal-start").val($('.temporal-start').val());
    $(".hidden-temporal-end").val($('.temporal-end').val());
  });
}

function getSummaryUrl(baseUrl, range, start, end, startParam, stopParam, dateOnly) {
  var summaryUrl = baseUrl;
  var params = getProductReceivedTimeRange(range, start, end, startParam, stopParam, dateOnly);
  summaryUrl += jQuery.param( params );
  return summaryUrl;
}

function getProductReceivedTimeRange(range, start, end, startParam, stopParam, dateOnly) {
  var params = {};
  if ((start && start !== 'undefined') || (end && end !== 'undefined')) {
    if (start && start !== 'undefined') params[startParam] = start;
    if (end && end !== 'undefined') params[stopParam] = end;
  } else {
    var today = new Date();
    today = new Date(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
    switch (range) {
    case "today":
      params[startParam] = getStartIsoDateTime(today, dateOnly);
      params[stopParam] = getStopIsoDateTime(today, dateOnly);
      break;
    case "yesterday":
      today.setDate(today.getDate() - 1);
      params[startParam] = getStartIsoDateTime(today, dateOnly);
      params[stopParam] = getStopIsoDateTime(today, dateOnly);
      break;
    case "thisMonth":
      var firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      var lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      params[startParam] = getStartIsoDateTime(firstDay, dateOnly);
      params[stopParam] = getStopIsoDateTime(lastDay, dateOnly);
      break;
    case "lastMonth":
      today.setDate(1);
      today.setMonth(today.getMonth() - 1);
      var firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      var lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      params[startParam] = getStartIsoDateTime(firstDay, dateOnly);
      params[stopParam] = getStopIsoDateTime(lastDay, dateOnly);
      break;
    default:
      break;
    }
  }
  return params;
}

/**
 * Returns date in ISO 8601 format with time 00:00:00.
 *
 * @param date
 *          JavaScript date object
 * @param dateOnly
 *          if true, don't return time
 * @returns date in ISO 8601 format with time 00:00:00
 */
function getStartIsoDateTime(date, dateOnly) {
  var dateStr = date.toISOString().substring(0, 10);
  if (dateOnly) return dateStr;
  else return dateStr + "T00:00:00";
}

/**
 * Returns date in ISO 8601 format with time 23:59:59.
 *
 * @param date
 *          JavaScript date object
 * @param dateOnly
 *          if true, don't return time
 * @returns date in ISO 8601 format with time 23:59:59
 */
function getStopIsoDateTime(date, dateOnly) {
  var dateStr = date.toISOString().substring(0, 10);
  if (dateOnly) return dateStr;
  else return dateStr + "T23:59:59";
}

/**
 * Displays metadata dialog for specified product.
 *
 * @param filename
 *            filename of product
 */
function displayMetadata(filename) {
  // List metadata keys that can be returned as comma-separated string
  var metKeysCommaSeparated = ["AncillaryInputName", "InputName"];

  $.getJSON( PRODUCT_URL + filename, function( data ) {
    var table = $("<table>");
    table.attr("class", "common filter");

    data.product["StoreLocation"] = data.product["FileURI"].substring(5);
    data.product["FileSize (Bytes)"] = data.product["FileSize"];
    delete data.product["FileLocation"];
    delete data.product["FileURI"];
    delete data.product["FileSize"];

    var keys = Object.keys(data.product).sort();
    $.each(keys, function( index, key ) {
      var row = $("<tr>");
      row.append($("<td>").text(key.replace(/([a-z])([A-Z])/g, "$1 $2")));
      if (metKeysCommaSeparated.indexOf(key) != -1) {
        var values = data.product[key].split(",");
        if (values.length > 1) {
          var list = $("<ul>");
          $.each(values, function( index, value ) {
            list.append($("<li>").text(value));
          });
          row.append($("<td>").append(list));
        } else {
          row.append($("<td>").text(data.product[key]));
        }
      } else {
        row.append($("<td>").text(data.product[key]));
      }
      table.append(row);
    });
    var div = $("<div>");
    div.attr("title", "Metadata for " + filename);
    div.append(table);
    div.dialog({
      width: 800,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

/**
 * Displays error message dialog containing Log File, Short Message, Detailed
 * Message and Failure Directory.
 * 
 * @param data
 *          JSON data returned by web service
 */
function displayErrorDialog(data) {
  if (Object.keys(data).length == 0) {
    alert("Can't find log file with this specific error message.");
  } else {
    var table = $("<table>").attr("class", "common");
    table.append($("<tr>").append($("<td>").text("Log File")).append($("<td>").text(data.LogFile)));
    table.append($("<tr>").append($("<td>").text("Short Message")).append($("<td>").text(data.ShortMessage)));
    table.append($("<tr>").append($("<td>").text("Detailed Message")).append($("<td>").text(data.DetailedMessage)));
    if (data.FailureDirectory) table.append($("<tr>").append($("<td>").text("Failure Directory")).append($("<td>").text(data.FailureDirectory)));
    
    var div = $("<div>");
    div.attr("title", "Error Message");
    div.append(table);
    div.dialog({
      width: 600,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  }
}
