<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>

<h3>Product Accountability</h3>
<p class="generated-timestamp">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>
<div id="tabs">
   <ul>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbitSummary/index.php">Half-Orbit Products</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/dailySummary/index.php">Daily L3 Products</a></li>
      <li><a href="#half-orbit">Half-Orbit Info</a></li>
   </ul>
   <div id="half-orbit">
<?php 
$module = App::Get()->loadModule();
require_once($module->modulePath . "/scripts/widgets/HalfOrbitFilterWidget.php");

$filterWidget = new HalfOrbitFilterWidget(array('temporalLabel' => "Half Orbit Date Time"));
$filterWidget->render();
?>
<br />
<table id="half-orbit-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Half Orbit</th>
         <th>Radar Data Status</th>
         <th>Radiometer Data Status</th>
         <th>Half Orbit Start Date Time</th>
         <th>Half Orbit Stop Date Time</th>
         <th>Radar Beginning Date Time</th>
         <th>Radar Ending Date Time</th>
         <th>Radiometer Beginning Date Time</th>
         <th>Radiometer Ending Date Time</th>
         <th>Orbit Path</th>
         <th>Begin Eclipse Date Time</th>
         <th>End Eclipse Date Time</th>
         <th>Last Modified</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
</div>
</div>
