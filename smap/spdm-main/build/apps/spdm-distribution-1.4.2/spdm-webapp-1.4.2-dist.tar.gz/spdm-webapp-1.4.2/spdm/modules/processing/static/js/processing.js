/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
var intervalId;
var workflowDefinitions = {};

$(document).ready(function() {
  //Load workflow definitions
  $.ajax({
    type: "GET",
    url: WORKFLOW_DEF_URL,
    dataType: "json",
    async: false,
    success: function(data) {
      $.each(data.wfdefinitions, function( index, value ) {
        workflowDefinitions[value.WFName] = value.WFTasks
      });
    },
    error: function(xhr, status, error) {
    }
  });

  $("#current-date").text((new Date()).toUTCString());

  addRefreshListener($("#processing-table"));

  // Parse query parameters
  var queryParameters = getQueryParameters();
  var start = queryParameters["start"];
  var end = queryParameters["end"];
  var status = queryParameters["status"];
  var node = queryParameters["node"];
  var workflow = queryParameters["workflow"];
  var task = queryParameters["task"];
  var processing = queryParameters["processing"];
  var byDuration = queryParameters["byDuration"];
  var startOrbitNumber = queryParameters["startOrbitNumber"];
  var stopOrbitNumber = queryParameters["stopOrbitNumber"];

  // Populate the Node Name select with values from web service
  populateNodeSelect(node);

  // Populate the Node Name select with values from web service
  populateWorkflowNameSelect(workflow, task);

  createDateTimePicker($('.temporal-start'), start);
  createDateTimePicker($('.temporal-end'), end, 23, 59, 59);

  // Build query string request to send to web service
  var queryString = [];
  if (start) {
    queryString.push("WorkflowStartTime>=" + start);
  }
  if (end) {
    queryString.push("WorkflowStartTime<=" + end);
  }
  if (status) {
    if (status instanceof Array) {
      var statusParams = [];
      $.each(status, function( index, value ) {
        $("input[name=status][value=" + value + "]").attr('checked', true);
        statusParams.push("Status=" + value)
      });
      queryString.push("(" + statusParams.join(" or ") + ")");
    } else {
      $("input[name=status][value=" + status + "]").attr('checked', true);
      queryString.push("Status=" + status);
    }
  }
  if (node) {
    queryString.push("NodeName=" + node);
  }
  if (workflow) {
    if (workflow instanceof Array) {
      var workflowParams = [];
      $.each(workflow, function( index, value ) {
        workflowParams.push(getWorkflowCondition(value));
      });
      queryString.push("(" + workflowParams.join(" or ") + ")");
    } else {
      queryString.push(getWorkflowCondition(workflow));
    }
  }
  if (task) {
    queryString.push("CurrentTaskName=" + task);
  }
  if (processing) {
    if (processing instanceof Array) {
      $.each(processing, function( index, value ) {
        $("input[name=processing][value=" + value + "]").attr('checked', true);
      });
    } else {
      $("input[name=processing][value=" + processing + "]").attr('checked', true);
      if (processing === "reprocessing") {
        queryString.push("ProcessingMode=reprocessing");
      } else {
        queryString.push("(ProcessingMode=forward or ProcessingMode=manual)");
      }
    }
  }
  if (startOrbitNumber) {
    $("input[name=startOrbitNumber]").val(startOrbitNumber);
    queryString.push("OrbitNumber>=" + startOrbitNumber);
  }
  if (stopOrbitNumber) {
    $("input[name=stopOrbitNumber]").val(stopOrbitNumber);
    queryString.push("OrbitNumber<=" + stopOrbitNumber);
  }

  var params = {order: "DESC"};
  var sortColIndex = 8; // By default sort by Workflow Start Time
  if (byDuration && byDuration == "true") {
    $("input[name=byDuration]").attr('checked', true);
    params["orderBy"] = "WorkflowDuration";
    sortColIndex = 9; // "Retrieve by Longest Duration" is checked so sort by Workflow Duration
  } else {
    params["orderBy"] = "WorkflowStartTime";
  }

  if (queryString.length > 0) {
    params["queryString"] = "'" + queryString.join(" and ") + "'";
  } else {
    params["queryString"] = "'1=1'";
  }
  var workflowUrl = WORKFLOW_URL + "q?" + jQuery.param( params );

  createDataTable("#processing-table",
    [[ sortColIndex, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     {
        "mData": 1,
        "aTargets": [ 1 ],
        "mRender": function ( data, type, full ) {
      	  if ( type === 'display' ) {
              return '<a href="javaScript:void(0);" onclick="displayWorkflow(\''+data+'\');">'+data+'</a>';
          } else {
            return data;
          }
        }
      },
      {
        "mData": 2,
        "aTargets": [ 2 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            if (data != 0) return '<a href="javaScript:void(0);" onclick="displayWorkflow(\''+data+'\');">'+data+'</a>';
            else return data;
          } else {
            return data;
          }
        }
      },
      {
        "mData": 3,
        "aTargets": [ 3 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            return '<a href="javaScript:void(0);" onclick="displayWorkflowDef(\''+data+'\');">'+data+'</a>';
          } else {
            return data;
          }
        }
      },
      {
        "mData": 5,
        "aTargets": [ 5 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            return getProgressMonitor(full);
          } else {
            return data;
          }
        },
        "sClass": "middle"
      },
      {
        "mData": 9,
        "aTargets": [ 9 ],
        "mRender": function ( data, type, full ) {
          return data.toFixed(3);
        }
      },
      {
        "mData": 7,
        "aTargets": [ 7 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            return getErrorMessage(full);
          } else {
            if (data == -1) {
              return "";
            } else {
              return data;
            }
          }
        }
      },
      {
        "mData": 11,
        "aTargets": [ 11 ],
        "mRender": function ( data, type, full ) {
          if ( type === 'display' ) {
            if (data == "N/A") {
              return data;
            } else {
              return '<a href="javaScript:void(0);" onclick="getClusterReport(\''+data+'\');">'+data+'</a>';
            }
          } else {
            return data;
          }
        }
    }],
    workflowUrl,
    [ { "mData": null },
      { "mData": "PSID" },
      { "mData": "ParentID" },
      { "mData": "WorkflowName" },
      { "mData": "OrbitKey", "sType": "orbit" },
      { "mData": "CurrentTaskName" },
      { "mData": "Status" },
      { "mData": "ErrorCode", "sType": "numeric_ignore_nan" },
      { "mData": "WorkflowStartTime" },
      { "mData": "WorkflowDuration" },
      { "mData": "Pid" },
      { "mData": "NodeName" },
      { "mData": "ProcessingMode" }, 
      { "mData": "TriggerVal", "sDefaultContent" : "" }],
    "workflows",
    true
  );
  
  $("#temporal-search-form").submit(function(event){
    //TODO Disable search button unless there are values
    //TODO Check that start < end
    $(".hidden-temporal-start").val($('.temporal-start').val());
    $(".hidden-temporal-end").val($('.temporal-end').val());
  });
});

var workflowDialog;
function displayWorkflow(processId) {
  var workflowKeys = {"PSID": "WorkflowID",
                      "WorkflowName": "",
                      "OrbitKey": "HalfOrbit",
                      "CompletedTaskDuration": "CompletedTasks",
                      "TasksWithSecondary": "",
                      "WorkflowStartTime": "",
                      "WorkflowDuration": "WorkflowDuration (Minutes)",
                      "Status": "",
                      "ErrorCode": "ErrorMessage",
                      "WorkflowInstanceID": "",
                      "ParentID": "",
                      "ParentWFInstID": "ParentWorkflowInstanceID",
                      "ProcessingMode": "",
                      "TriggerVal": "TriggerValue"};  
  var currentTaskKeys = {"CurrentTaskName": "",
                         "CurrentTaskStartTime": "",
                         "CurrentTaskDuration": "CurrentTaskDuration (Minutes)",
                         "Pid": "",
                         "NodeName": "",
                         "QueueName": "",
                         "JobID": ""};
  $.getJSON( WORKFLOW_URL + processId, function( data ) {
    data.workflow["OrbitKey"] = data.workflow["OrbitNumber"] + " " + data.workflow["OrbitDirection"];

    var wfTable = $("<table>");
    wfTable.attr("class", "common workflow");
    appendMetadataRows(wfTable, data, workflowKeys);

    var currTaskTable = $("<table>");
    currTaskTable.attr("class", "common workflow");
    appendMetadataRows(currTaskTable, data, currentTaskKeys);

    // Close dialog window if one is already opened
    if ($("div#workflow-dialog").length) $("div#workflow-dialog").dialog('close');

    workflowDialog = $("<div>").attr("id", "workflow-dialog");
    workflowDialog.attr("title", "Workflow " + processId);
    workflowDialog.append($("<h5>").text("Workflow Metadata"));
    workflowDialog.append(wfTable);
    workflowDialog.append($("<h5>").text("Current Task Metadata"));
    workflowDialog.append(currTaskTable);
    workflowDialog.append($("<h5>").text("Generated Products"));
    
    if (data.workflow["Products"] && data.workflow["Products"].length > 0) {
      //List of generated products
      var generatedProducts = $("<ul>");
      $.each(data.workflow["Products"], function( index, value ) {
        var filename = value.substring(value.lastIndexOf("/") + 1, value.length);
        generatedProducts.append($("<li>").append($("<a>")
            .text(filename)
            .attr("class", "productLink")
            .attr("href", "javaScript:void(0);")
            .attr("onclick", "displayMetadata('" + filename + "');")));
      });
      workflowDialog.append(generatedProducts);
    } else {
      workflowDialog.append($("<p>").text("None"));
    }

    workflowDialog.dialog({
      width: 720,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

function appendMetadataRows(table, data, keys) {
  $.each(keys, function (key, value ) {
    var row = $("<tr>");
    var displayKey = key;
    if (value != "") {
      displayKey = value;
    }
    var firstCol = $("<td>");
    firstCol.attr("class", "first-col");
    row.append(firstCol.text(displayKey.replace(/([a-z])([A-Z])/g, "$1 $2")));
    if (key == "CompletedTaskDuration" && data.workflow[key]) {
      var tasks = data.workflow[key].split(",");
      var list = $("<ol>");
      $.each(tasks, function( index, value ) {
        var tasksDurationPair = value.split(":");
        var displayText = tasksDurationPair[0];
        if (tasksDurationPair.length > 2) {
          displayText += ":" + tasksDurationPair[1];
        }
        displayText += " (took " + (tasksDurationPair[tasksDurationPair.length - 1] / 60000).toFixed(3) + " minutes)";
        list.append($("<li>").text(displayText));
      });
      row.append($("<td>").append(list));
    } else if (key == "ParentID" && data.workflow[key] != 0) {
      row.append($("<td>").append($("<a>")
        .text(data.workflow[key])
        .attr("class", "workflowLink")
        .attr("href", "javaScript:void(0);")
        .attr("onclick", "displayWorkflow(" + data.workflow[key] + ");")));
    } else if (key == "ErrorCode") {
      row.append($("<td>").append($(getErrorMessage(data.workflow)).attr("class", "workflowLink")));
    } else {
      if (!isNaN(data.workflow[key]) && (data.workflow[key] % 1 != 0)) {
        row.append($("<td>").text(data.workflow[key].toFixed(3)));
      } else{
        row.append($("<td>").text(data.workflow[key] ? data.workflow[key] : ""));
      }
    }
    table.append(row);
  });
}

function displayWorkflowDef(workflowName) {
  $.getJSON( WORKFLOW_DEF_URL + workflowName, function( data ) {
    var tasks = data.wfdefinition[workflowName].split(";");
    var list = $("<ol>");
    $.each(tasks, function( index, value ) {
      list.append($("<li>").text(value));
    });
    var div = $("<div>");
    div.attr("title", workflowName);
    div.append($("<p>").text("Tasks List"));
    div.append(list);
    div.dialog({
      width: 500,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

function displayNode(name, id, load, capacity, jobs) {
  $.getJSON( WORKFLOW_NODE_URL + id, function( data ) {
    var table = $("<table>");
    table.attr("class", "common node");
    var row = $("<tr>");
    row.append($("<td>").text("Queue Lists"));
    var queue = data.node["Queue Lists"].split(",");
    var list = $("<ul>");
    $.each(queue, function( index, value ) {
      list.append($("<li>").text(value));
    });
    row.append($("<td>").append(list));
    table.append(row);

    row = $("<tr>");
    row.append($("<td>").text("URL"));
    row.append($("<td>").text(data.node.URL.substring(1, data.node.URL.length - 1)));
    table.append(row);

    row = $("<tr>");
    row.append($("<td>").text("Load/Capacity"));
    row.append($("<td>").text(load + "/" + capacity));
    table.append(row);

    row = $("<tr>");
    row.append($("<td>").text("Executing Jobs"));
    var jobList = $("<ul>");
    $.each(jobs, function( index, value ) {
      jobList.append($("<li>").text(value.Name + "," + value.ID));
    });
    row.append($("<td>").append(jobList));
    table.append(row);

    var div = $("<div>");
    div.attr("title", name);
    div.append(table);
    div.dialog({
      width: 720,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

function getClusterReport(nodeName) {
  $.getJSON( WORKFLOW_CLUSTER_REPORT_URL, function( data ) {
    $.each(data.nodes, function( index, value ) {
      if (value.ID == nodeName) {
        getExecutingJob(nodeName, value.ID, value.Load, value.Capacity);
        return false;
      }
    });
  });
}

function getExecutingJob(nodeName, id, load, capacity) {
  $.getJSON( WORKFLOW_EXECUTING_JOB_URL, function( data ) {
    var jobs = [];
    $.each(data.jobs, function( index, value ) {
      if (value.NodeName == nodeName) {
        jobs.push({"Name": value.Name, "ID": value.ID});
      }
    });
    displayNode(nodeName, id, load, capacity, jobs);
  });
}

/**
 * Populates select input with node names from web service.
 *
 * @param node
 *            current selected node value
 */
function populateNodeSelect(node) {
  $.getJSON( WORKFLOW_NODE_URL, function( data ) {
    data.nodes.sort(function(a, b){
      if (a.ID < b.ID) return -1;
      if (a.ID > b.ID) return 1;
      return 0;
    });
    var select = $("select[name=node]");
    select.append($("<option>").text("--------------------").val(""));
    $.each(data.nodes, function( index, value ) {
      select.append($("<option>").text(value.ID).val(value.ID));
    });
    select.val(node);
  });
}

function sortWorkflowDefinitions(data) {
  data.wfdefinitions.sort(function(a, b){
    if (a.WFName < b.WFName) return -1;
    if (a.WFName > b.WFName) return 1;
    return 0;
  });
}

/**
 * Populates select input with workflow names from web service.
 *
 * @param workflowName
 *            current selected workflow name
 * @param taskName
 *            current selected task name
 */
function populateWorkflowNameSelect(workflowName, taskName) {
  $.getJSON( WORKFLOW_DEF_URL, function( data ) {
    var tasks = [];

    //Add wildcard workflow names
    data.wfdefinitions.push({WFName: "L2*"});
    data.wfdefinitions.push({WFName: "L3*"});
    data.wfdefinitions.push({WFName: "Radar*"});
    data.wfdefinitions.push({WFName: "Radiometer*"});
    sortWorkflowDefinitions(data);
    var select = $("select[name=workflow]");
    $.each(data.wfdefinitions, function( index, value ) {
      select.append($("<option>").text(value.WFName).val(value.WFName));
      
      if (value.WFTasks) {
        var wfTasks = value.WFTasks.split(";");
        $.each(wfTasks, function( index, value ) {
          if ($.inArray(value, tasks) === -1) {
            tasks.push(value);
          }
        });
      }
    });
    select.val(workflowName);
    $("select[name=workflow]").chosen();
    
    tasks.sort(function (a, b) {
      return a.toLowerCase().localeCompare(b.toLowerCase());
    });
    var taskSelect = $("select[name=task]");
    taskSelect.append($("<option>").text("-----------------------------").val(""));
    $.each(tasks, function( index, value ) {
      taskSelect.append($("<option>").text(value).val(value));
    });
    taskSelect.val(taskName);
  });
}

function displayWorkflowDefinitions() {
  $.getJSON( WORKFLOW_DEF_URL, function( data ) {
    sortWorkflowDefinitions(data);
    var table = $("<table>").attr("class", "workflow-def");
    var row;
    $.each(data.wfdefinitions, function( index, value ) {
      if (index % 4 == 0) {
        row = $("<tr>");
        table.append(row);
      }
      row.append($("<td>").append($("<a>")
          .text(value.WFName)
          .attr("class", "workflowLink")
          .attr("href", "javaScript:void(0);")
          .attr("onclick", "displayWorkflowDef('" + value.WFName + "');")));
    });
    var div = $("<div>");
    div.attr("title", "Workflows");
    div.append(table);
    div.dialog({
      width: 800,
      modal: true,
      close: function(event, ui) {
        $( this ).dialog( "destroy" );
      }
    });
  });
}

/**
 * Returns error message for specified workflow object of the format
 * [WFID-<PSID>:<ErrorCode>] - <ErrorMsg>
 * 
 * @param data
 *          workflow object
 * @returns {String}
 */
function getErrorMessage(data) {
  if (data.ErrorCode == -1) {
    return "";
  } else {
    var errorCode = "WFID-" + data.PSID + ":" + data.ErrorCode;
    var shortMsg = "[" + errorCode + "] - " + data.ErrorMsg;
    return '<a href="javaScript:void(0);" onclick="getDetailedErrorMsg(\'' + data.WorkflowInstanceID + '\',\'' + errorCode + '\',\'' + data.WorkflowStartTime.substring(0, 10) + '\',\'' + data.Status + '\',\'' + data.NodeName + '\');">'+shortMsg+'</a>';
  }
}

function toggleFilters(filter) {
  $(filter).next().toggle();
  $(filter).toggleClass("expand collapsed");
}

function selectAllStatus(select) {
  $("input[name=status]").each(function() {
    $(this).prop('checked', select);
  });
}

function getDetailedErrorMsg(id, errorCode, date, status, node) {
  var queryParams = {
    id : id,
    errorCode : errorCode,
    date : date,
    status : status,
    node : node
  };
  $.getJSON( WORKFLOW_DETAILED_ERROR_URL + "q?" + jQuery.param( queryParams ), function( data ) {
    displayErrorDialog(data);
  });
}

// List of tasks whose name should not get displayed
var hiddenTasks = ["CheckProcessAscendingDataTask", "LaunchL0BTask", "LaunchStageProductTask", "MoveToAnalysisAreaTask", "removeRunConfigMetadataTask", "StoreOrbitMetInDBTask", "UpdateMetadataInFMTask", "CheckColdSkyTask"];

// Mapping of tasks name to shorten version
var tasksMap = {"L0ARadarTask": "0A",
    "L0ARadiometerTask": "0A",
    "L0BRadarTask": "0B",
    "L0BRadiometerTask": "0B",
    "L1ARadarTask": "1A",
    "L1ARadiometerTask": "1A",
    "L1BS0LoResTask": "1B",
    "L1CS0HiResOnlyTask": "1C",
    "L1CS0HiResTask": "1C",
    "RadarCalPPOnlyTask": "Cal",
    "RadarCalPPTask": "Cal",
    "L1BTBTask": "1B",
    "L1BTBETask": "1BE",
    "L1BTB_EPTask": "1B",
    "L1BTB_L1BE-L1CETask": "1B",
    "L1CTBTask": "1C",
    "L1CTBETask": "1CE",
    "L2S0S1PPTask": "2S0S1",
    "L2SMATask": "2A",
    "L2SMPTask": "2P",
    "L2SMPETask": "2PE",
    "L2SMSPTask": "2SP",
    "L2SMAPTask": "2AP",
    "L2FTAPPTask": "2FTA",
    "L3SMAOnlyTask": "3A",
    "L3SMATask": "3A",
    "L3SMPTask": "3P",
    "L3SMPETask": "3PE",
    "L3SMAPTask": "3AP",
    "L3FTATask": "3FTA",
    "L3FTPTask": "3FTP",
    "L3FTPETask": "3FTPE"};

function getProgressMonitor(data) {
  // Get list of completed tasks
  var completedTasks = [];
  if (data.CompletedTaskDuration) {
  var completedTaskDuration = data.CompletedTaskDuration.split(",");
    $.each(completedTaskDuration, function( index, value ) {
      var tasksPair = value.split(":");
      completedTasks.push(tasksPair[0]);
    });
  }

  var table = $("<table>").attr("class", "progress");
  var row = $("<tr>");
  table.append(row);

  var tasks = workflowDefinitions[data.WorkflowName] ? workflowDefinitions[data.WorkflowName].split(";") : [];
  var list = $("<ol>");
  var foundCurrentTask = false;
  $.each(tasks, function( index, value ) {
    var cell = $("<td>");
    var hoverDiv = $("<div>").attr("title", value);

    if ($.inArray(value, hiddenTasks) === -1) {
      if (value in tasksMap) {
        hoverDiv.text(tasksMap[value]);
      } else {
        hoverDiv.text(value.substring(0, value.length - 4));
      }
    } else {
      hoverDiv.attr("class", "empty");
    }
    cell.append(hoverDiv);
    row.append(cell);

    if (completedTasks.length > 0 && index < completedTasks.length) {
      cell.attr("class", "processed");
    } else {
      if (!foundCurrentTask && value == data.CurrentTaskName) {
        foundCurrentTask = true;
        if (data.Status === 'PROCESS_FAILED' || data.Status === 'KILLED') {
          cell.attr("class", "failed");
        } else if (data.Status === 'PRECONDITION_FAILED') {
          cell.attr("class", "preconditioned-failed");
        }  else if (data.Status === 'JOB_SENT' || data.Status === 'PRECONDITION_PASSED' || data.Status === 'RUNNING')  {
          cell.attr("class", "running");
        } else if (data.Status === 'PROCESSED') {
          cell.attr("class", "processed");
        } else {
          //No color needed for other status
        }
      } else {
        // No color needed on future tasks
      }
    }
  });
  return table.prop('outerHTML');
}

function getWorkflowCondition(workflow) {
  if (workflow.indexOf("*") != -1) {
    //Replace * with %
    workflow = workflow.replace(/\*/g, '%');
    return "WorkflowName like ''" + workflow + "'";
  } else {
    return "WorkflowName=" + workflow;
  }
}
