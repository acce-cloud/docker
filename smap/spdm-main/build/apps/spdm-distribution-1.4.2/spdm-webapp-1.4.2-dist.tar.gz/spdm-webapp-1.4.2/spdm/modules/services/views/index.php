<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>
<h3>Services Status</h3>
<div class="status">
<p class="current">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>
<div class="crawler">
   <h4>Crawler Status</h4>
   <table id="crawler" class="common">
      <tr>
         <th class="first-col">Name</th>
         <th class="second-col">URL</th>
         <th class="third-col">Process ID</th>
         <th>Status</th>
      </tr>
   </table>
</div>

<h4>Server Status</h4>
<table id="server" class="common">
   <tr>
      <th class="first-col">Name</th>
      <th class="second-col">URL</th>
      <th class="third-col">Process ID</th>
      <th>Status</th>
   </tr>
</table>

<h4>Batch Stub Status</h4>
<table id="batch-stub" class="common">
   <tr>
      <th class="first-col">URL</th>
      <th class="second-col">Process ID</th>
      <th>Status</th>
   </tr>
</table>

<h4>Timer Status</h4>
<table id="timer" class="common">
   <tr>
      <th class="first-col">Name</th>
      <th class="second-col">Process ID</th>
      <th>Status</th>
   </tr>
</table>

</div>