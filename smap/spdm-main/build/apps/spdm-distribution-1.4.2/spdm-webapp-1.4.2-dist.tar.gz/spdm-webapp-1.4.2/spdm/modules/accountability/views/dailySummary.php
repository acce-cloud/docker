<?php
/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
?>

<h3>Product Accountability</h3>
<p class="generated-timestamp">Current Information as of: <span id="current-date"></span></p>
<p class="auto-refresh"><input type="button" id="auto-refresh" value="Enable Auto Refresh" /></p>
<div id="tabs">
   <ul>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbitSummary/index.php">Half-Orbit Products</a></li>
      <li><a href="#daily-summary">Daily L3 Products</a></li>
      <li><a href="<?php echo SITE_ROOT?>/accountability/halfOrbit/index.php">Half-Orbit Info</a></li>
   </ul>
   <div id="daily-summary">
<form id="temporal-form" action="" method="get">
<table class="form">
<tr><td>Last Modified Date Time</td><td>
<div id="temporal-range">
<input onchange="this.form.submit();" type="radio" id="temporal-1" name="range" value="today"><label for="temporal-1">Today</label>
<input onchange="this.form.submit();" type="radio" id="temporal-2" name="range" value="yesterday"><label for="temporal-2">Yesterday</label>
<input onchange="this.form.submit();" type="radio" id="temporal-3" name="range" value="thisMonth"><label for="temporal-3">This Month</label>
<input onchange="this.form.submit();" type="radio" id="temporal-4" name="range" value="lastMonth"><label for="temporal-4">Last Month</label>
</div>
</td><td>
<span>&nbsp;or between&nbsp;</span>
<input type="text" class="temporal-start" />
<input type="hidden" class="hidden-temporal-start" name="start" />
<span>&nbsp;and&nbsp;</span>
<input type="text" class="temporal-end" />
<input type="hidden" class="hidden-temporal-end" name="end" />
</td></tr>
<tr><td class="or-label">OR</td></tr>
<tr><td><label>Granule Date Between</label></td>
<td>
<input type="text" class="granule-date-temporal-start" name="startGranuleDate" />
<label>&nbsp;and&nbsp;</label>
<input type="text" class="granule-date-temporal-stop" name="stopGranuleDate" />
</td></tr>
</table>
<button class="temporal-search-button" type="submit">Apply</button>
<button onclick="window.location=window.location.pathname; return false;">Reset</button>
</form>
<br />
<table id="daily-summary-table" class="tablesorter">
   <thead>
      <tr>
         <th></th>
         <th>Start Orbit</th>
         <th>Stop Orbit</th>
         <th>Granule Date</th>
         <th>Last Modified</th>
         <th>L3SMA</th>
         <th>L3SMP</th>
         <th>L3SMPE</th>
         <th>L3SMAP</th>
         <th>L3FTA</th>
         <th>L3FTP</th>
         <th>L3FTPE</th>
      </tr>
   </thead>
   <tbody>
   </tbody>
</table>
</br>
<p><span class="running">R</span> = Running, <span class="processed">P</span> = Processed (# of orbit based files used/generated/expected), <span class="failed">F</span> = Failed</p>
</div>
</div>
