/*
 * Copyright 2009-2015, by the California Institute of Technology.
 * ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
 *
 * @version $Id$
 */
$(document).ready(function() {
  $("#current-date").text((new Date()).toUTCString());

  //Parse query parameters
  var queryParameters = getQueryParameters();
  var range = queryParameters["range"];
  var start = queryParameters["start"];
  var end = queryParameters["end"];
  var status = queryParameters["status"];
  var expireStart = queryParameters["expireStart"];
  var expireEnd = queryParameters["expireEnd"];
  var startOrbitNumber = queryParameters["startOrbitNumber"];
  var stopOrbitNumber = queryParameters["stopOrbitNumber"];
  var orbitStart = queryParameters["orbitStart"];
  var orbitEnd = queryParameters["orbitEnd"];
  var name = queryParameters["name"];
  
  instantiateTemporalFilterWidget(range, start, end);

  createDateTimePicker($('.expire-temporal-start'), expireStart);
  createDateTimePicker($('.expire-temporal-end'), expireEnd, 23, 59, 59);
  
  createDateTimePicker($('.orbit-temporal-start'), orbitStart);
  createDateTimePicker($('.orbit-temporal-end'), orbitEnd, 23, 59, 59);

  populateTimerNameSelect(name);

  // Build query string request to send to web service
  var queryString = [];

  var params = getProductReceivedTimeRange(range, start, end, "startTime", "stopTime");
  if ("startTime" in params) {
    queryString.push("StartTime>=" + params["startTime"]);
  }
  if ("stopTime" in params) {
    queryString.push("StartTime<=" + params["stopTime"]);
  }
  if (status) {
    if (status instanceof Array) {
      var statusParams = [];
      $.each(status, function( index, value ) {
        $("input[name=status][value=" + value + "]").attr('checked', true);
        statusParams.push("Status=" + value)
      });
      queryString.push("(" + statusParams.join(" or ") + ")");
    } else {
      $("input[name=status][value=" + status + "]").attr('checked', true);
      queryString.push("Status=" + status);
    }
  }
  if (expireStart) {
    queryString.push("ExpireTime>=" + expireStart);
  }
  if (expireEnd) {
    queryString.push("ExpireTime<=" + expireEnd);
  }
  if (startOrbitNumber) {
    $("input[name=startOrbitNumber]").val(startOrbitNumber);
    queryString.push("OrbitNumber>=" + startOrbitNumber);
  }
  if (stopOrbitNumber) {
    $("input[name=stopOrbitNumber]").val(stopOrbitNumber);
    queryString.push("OrbitNumber<=" + stopOrbitNumber);
  }
  if (orbitStart) {
    queryString.push("HalfOrbitStartDateTime>=" + orbitStart);
  }
  if (orbitEnd) {
    queryString.push("HalfOrbitStartDateTime<=" + orbitEnd);
  }
  if (name) {
    if (name instanceof Array) {
      var timerParams = [];
      $.each(name, function( index, value ) {
        timerParams.push("SPSName=" + value);
      });
      queryString.push("(" + timerParams.join(" or ") + ")");
    } else {
      queryString.push("SPSName=" + name);
    }
  }

  var timerUrl = TIMER_URL;
  if (queryString.length > 0) {
    var queryParams = {};
    queryParams["queryString"] = "'" + queryString.join(" and ") + "'";
    timerUrl = TIMER_URL + "q?" + jQuery.param( queryParams );
  }

  createDataTable("#data-table",
    [[ 5, "desc" ]],
    [{ "bSortable": false, "aTargets": [ 0 ] },
     { 
      "mData": 7,
      "aTargets": [ 7 ],
      "mRender": function ( data, type, full ) {
        if ( type === 'display' ) {
          return data.replace(/,/g, ", ");
        } else {
          return data;
        }
      }
    }],
    timerUrl,
    [ { "mData": null },
      { "mData": "OrbitKey", "sType": "orbit" },
      { "mData": "HalfOrbitStartDateTime" },
      { "mData": "SpsName" },
      { "mData": "StartTime" },
      { "mData": "ExpireTime" },
      { "mData": "Status" },
      { "mData": "InputNames" }
    ],
    "timers",
    true
  );
});

function selectAllStatus(select) {
  $("input[name=status]").each(function() {
    $(this).prop('checked', select);
  });
}

/**
 * Populates select input with timer names from web service.
 *
 * @param name
 *            current selected timer name value
 */
function populateTimerNameSelect(name) {
  $.getJSON( TIMER_NAME_URL, function( data ) {
    data.timers.sort();
    var select = $("select[name=name]");
    $.each(data.timers, function( index, value ) {
      select.append($("<option>").text(value).val(value));
    });
    select.val(name);
    $("select[name=name]").chosen();
  });
}
