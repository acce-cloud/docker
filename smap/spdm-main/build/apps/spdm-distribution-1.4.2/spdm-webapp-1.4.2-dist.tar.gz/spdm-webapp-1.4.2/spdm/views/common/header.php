<?php
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Application Header File
 *
 * This file represents a sample application header file that will be displayed
 * with every application view (unless the view has explicitly requested
 * a different header file, or no header file at all). To customize the header
 * file, you have two options:
 * 
 * 1) make changes to this file directly
 * 2) create a new header file, and update config.ini to point to it, instead
 */
?>
<!DOCTYPE html>
<html>
<head>
<title>SMAP SPDM OODT Balance Application</title>

<!-- Base stylesheets -->
<link rel="stylesheet" type="text/css" href="<?php echo SITE_ROOT .'/static/css/balance/balance.css'?>"/>

<!-- Base Javascript -->

<!-- Dynamically Added Stylesheets -->
<!-- STYLESHEETS -->

<!-- Dynamically Added Javascripts -->
<!-- JAVASCRIPTS -->

<!-- Site specific stylesheet overrides -->
<link rel="stylesheet" type="text/css" href="<?php echo SITE_ROOT .'/static/css/site.css'?>"/>

</head>
<body>
<div class="container_background" align="center">
<div id="top_spacecraft" align="center"></div>
<div id="top_siteBanner" align="left">
<img width="311" height="62" border="0" alt="SMAP - Soil Moisture Active Passive - Mapping soil moisture and freeze/thaw state from Space" src="<?php echo SITE_ROOT .'/static/img/top_siteBanner_new.png'?>"/>
</div>
   <div id="menu_container">
      <ul id="menu_bar">
         <li><a class="first" href="<?php echo SITE_ROOT?>/services/index.php">MAIN</a></li>
<?php
   $processingUrl = SITE_ROOT."/processing/index.php";
   if (isset(App::Get()->settings['statuses'])) { 
      $processingUrl .= "?";
      foreach (App::Get()->settings['statuses'] as $status) {
         $processingUrl .= "status=".trim($status)."&amp;";
      }
      $processingUrl = substr($processingUrl, 0, -5);
   }
?>
         <li><a href="<?php echo $processingUrl?>">PROCESSING MONITOR</a></li>
         <li><a href="<?php echo SITE_ROOT?>/resource/index.php">RESOURCE MONITOR</a></li>
         <li><a href="<?php echo SITE_ROOT?>/timer/index.php?range=today">TIMER MONITOR</a></li>
         <li><a href="<?php echo SITE_ROOT?>/data/incoming/index.php?range=today">DATA BROWSE</a></li>
         <li><a class="last" href="<?php echo SITE_ROOT?>/accountability/halfOrbitSummary/index.php?range=today">PRODUCT ACCOUNTABILITY</a></li>
      </ul>
   </div>

<div class="container" align="left">


<?php
	// This retrieves any 'flash' messages that should be displayed to the user
	echo App::Get()->GetMessages();
?>
   <div id="content">
   
